import React, { useEffect, useState } from 'react';
import {
  Wrench,
  Shield,
  Database,
  CheckCircle2,
  ShoppingCart,
  ShoppingBag,
  Package,
  Truck,
  Users,
  BarChart3,
  UserCog,
  Settings,
  ShieldCheck,
  LayoutDashboard,
  AlertTriangle,
} from 'lucide-react';
import { UserSession, Product, Category } from './types/ipc';
import { AuthBanner } from './components/AuthBanner';
import { LoginView } from './components/auth/LoginView';
import { DashboardView } from './components/dashboard/DashboardView';
import { PosView } from './components/pos/PosView';
import { SalesHistoryView } from './components/pos/SalesHistoryView';
import { ProductsView } from './components/products/ProductsView';
import { SuppliersView } from './components/suppliers/SuppliersView';
import { CustomersView } from './components/customers/CustomersView';
import { ReportsView } from './components/reports/ReportsView';
import { UsersView } from './components/users/UsersView';
import { SettingsView } from './components/settings/SettingsView';
import { AuditLogView } from './components/audit/AuditLogView';
import { SyncStatusBadge } from './components/sync/SyncStatusBadge';
import { SyncSettingsModal } from './components/sync/SyncSettingsModal';
import { FirstRunWizardModal } from './components/wizard/FirstRunWizardModal';
import { ToastProvider } from './context/ToastContext';
import { Language, translations } from './i18n/translations';

export default function App() {
  return (
    <ToastProvider>
      <MainApp />
    </ToastProvider>
  );
}

function MainApp() {
  const [currentSession, setCurrentSession] = useState<UserSession | null>(null);
  const [activeTab, setActiveTab] = useState<
    'dashboard' | 'pos' | 'sales' | 'customers' | 'products' | 'suppliers' | 'reports' | 'users' | 'settings' | 'audit'
  >('dashboard');

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(false);
  const [dueCustomerCount, setDueCustomerCount] = useState<number>(0);
  const [showSyncModal, setShowSyncModal] = useState(false);
  const [showWizardModal, setShowWizardModal] = useState(false);
  const [lang, setLang] = useState<Language>('bn'); // Default to Bangla for BD shops

  const isElectron = Boolean(window.api && window.api.ping);

  const t = translations[lang];

  const fetchCatalog = async () => {
    if (!window.api) return;
    setLoading(true);
    try {
      const [prods, cats, dueSummary] = await Promise.all([
        window.api.products.list(),
        window.api.categories.list(),
        window.api.customers.getDueSummary().catch(() => null),
      ]);
      setProducts(prods);
      setCategories(cats);
      if (dueSummary) {
        setDueCustomerCount(dueSummary.customers_with_due_count || 0);
      }
    } catch (err: any) {
      console.error('Failed to fetch catalog:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (window.api) {
      // Check first-run status
      window.api.wizard?.checkStatus().then((res) => {
        if (res.isFirstRun) {
          setShowWizardModal(true);
        }
      });

      // Check current session WITHOUT auto-login
      window.api.auth.getSession().then((sess) => {
        if (sess) {
          setCurrentSession(sess);
          fetchCatalog();
          if (sess.role === 'staff') {
            setActiveTab('pos');
          }
        }
      });
    }
  }, []);

  const handleLoginSuccess = (sess: UserSession) => {
    setCurrentSession(sess);
    fetchCatalog();
    if (sess.role === 'staff') {
      setActiveTab('pos');
    } else {
      setActiveTab('dashboard');
    }
  };

  const handleLogout = async () => {
    if (!window.api) return;
    try {
      await window.api.auth.logout();
    } catch (err) {
      console.error('Logout error:', err);
    }
    setCurrentSession(null);
    setProducts([]);
    setCategories([]);
    setActiveTab('dashboard');
  };

  const handleAddCategory = async (name: string): Promise<Category | null> => {
    if (!window.api) return null;
    try {
      const cat = await window.api.categories.create(name);
      setCategories((prev) => [...prev, cat]);
      return cat;
    } catch (err: any) {
      console.error('Failed to add category:', err);
      return null;
    }
  };

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'bn' ? 'en' : 'bn'));
  };

  // If user is not authenticated, render Login Screen
  if (!currentSession) {
    return (
      <>
        <LoginView
          onLoginSuccess={handleLoginSuccess}
          lang={lang}
          onLanguageToggle={toggleLanguage}
        />
        <FirstRunWizardModal
          isOpen={showWizardModal}
          onCompleted={() => {
            setShowWizardModal(false);
            fetchCatalog();
          }}
        />
      </>
    );
  }

  const isOwner = currentSession.role === 'owner';
  const lowStockCount = products.filter((p) => p.stock_qty <= (p.low_stock_threshold ?? 5)).length;

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-100 text-slate-900 font-sans overflow-hidden select-none">
      {/* Top Session/Role Banner */}
      <div className="flex-shrink-0">
        <AuthBanner
          currentSession={currentSession}
          onLogout={handleLogout}
          lang={lang}
          onLanguageToggle={toggleLanguage}
        />
      </div>

      {!isElectron && (
        <div className="flex-shrink-0 bg-amber-500 text-slate-950 px-4 py-1 text-xs font-mono font-bold flex items-center justify-between border-b border-amber-600 shadow-sm">
          <span>⚠️ Web Browser Preview Mode. SQLite DB active natively in Electron.</span>
          <span className="text-[11px] bg-black/20 px-2 py-0.5 rounded">npm run electron:dev</span>
        </div>
      )}

      {/* Main Navigation Header */}
      <header className="flex-shrink-0 bg-white border-b border-slate-200 shadow-sm px-4 sm:px-6 py-2.5 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-sky-50 text-sky-600 rounded-xl border border-sky-200 shadow-sm">
            <Wrench className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-base sm:text-lg font-extrabold tracking-tight text-slate-900 font-sans">
                {lang === 'bn' ? 'মেকানিক্যাল শপ POS' : 'Mechanical Shop POS'}
              </h1>
              <span className="hidden sm:inline-block text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-300 px-2 py-0.5 rounded-full">
                v1.0 Production
              </span>
              {isOwner && <SyncStatusBadge onOpenSyncModal={() => setShowSyncModal(true)} />}
            </div>
            <p className="text-[11px] text-slate-500 font-mono">
              Offline-First Desktop Terminal · Bangladesh
            </p>
          </div>
        </div>

        {/* Tab Navigation */}
        <nav className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-semibold overflow-x-auto max-w-full">
          {isOwner && (
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all whitespace-nowrap ${
                activeTab === 'dashboard'
                  ? 'bg-sky-600 text-white font-bold shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-white'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>{t.navDashboard}</span>
            </button>
          )}

          <button
            onClick={() => setActiveTab('pos')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all whitespace-nowrap ${
              activeTab === 'pos'
                ? 'bg-sky-600 text-white font-bold shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>{t.navPos}</span>
          </button>

          <button
            onClick={() => setActiveTab('sales')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all whitespace-nowrap ${
              activeTab === 'sales'
                ? 'bg-sky-600 text-white font-bold shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>{t.navSales}</span>
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all whitespace-nowrap ${
              activeTab === 'customers'
                ? 'bg-sky-600 text-white font-bold shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>{t.navCustomers}</span>
            {dueCustomerCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 bg-amber-100 text-amber-800 border border-amber-300 rounded-full text-[10px] font-mono font-bold">
                {dueCustomerCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('products')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all whitespace-nowrap ${
              activeTab === 'products'
                ? 'bg-sky-600 text-white font-bold shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            <span>{t.navProducts}</span>
            {lowStockCount > 0 && (
              <span
                className="ml-1 px-1.5 py-0.2 bg-rose-100 text-rose-800 border border-rose-300 rounded-full text-[10px] font-mono font-bold animate-pulse"
                title={`${lowStockCount} items below minimum stock threshold`}
              >
                {lowStockCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('suppliers')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all whitespace-nowrap ${
              activeTab === 'suppliers'
                ? 'bg-sky-600 text-white font-bold shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            <span>{t.navSuppliers}</span>
          </button>

          <button
            onClick={() => setActiveTab('reports')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all whitespace-nowrap ${
              activeTab === 'reports'
                ? 'bg-sky-600 text-white font-bold shadow-sm'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>{t.navReports}</span>
          </button>

          {isOwner && (
            <>
              <button
                onClick={() => setActiveTab('users')}
                className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all whitespace-nowrap ${
                  activeTab === 'users'
                    ? 'bg-sky-600 text-white font-bold shadow-sm'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white'
                }`}
              >
                <UserCog className="w-3.5 h-3.5" />
                <span>{t.navUsers}</span>
              </button>

              <button
                onClick={() => setActiveTab('settings')}
                className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all whitespace-nowrap ${
                  activeTab === 'settings'
                    ? 'bg-sky-600 text-white font-bold shadow-sm'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white'
                }`}
              >
                <Settings className="w-3.5 h-3.5" />
                <span>{t.navSettings}</span>
              </button>

              <button
                onClick={() => setActiveTab('audit')}
                className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all whitespace-nowrap ${
                  activeTab === 'audit'
                    ? 'bg-sky-600 text-white font-bold shadow-sm'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-white'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{t.navAudit}</span>
              </button>
            </>
          )}
        </nav>
      </header>

      {/* Main Viewport */}
      <main className="flex-1 p-3 sm:p-4 max-w-[1600px] mx-auto w-full overflow-hidden flex flex-col min-h-0">
        {activeTab === 'dashboard' && isOwner && (
          <DashboardView
            currentSession={currentSession}
            products={products}
            onNavigateTab={(tab) => setActiveTab(tab as any)}
            lang={lang}
          />
        )}

        {activeTab === 'pos' && (
          <PosView
            products={products}
            currentSession={currentSession}
            onRefreshProducts={fetchCatalog}
          />
        )}

        {activeTab === 'sales' && <SalesHistoryView currentSession={currentSession} />}

        {activeTab === 'customers' && <CustomersView currentSession={currentSession} />}

        {activeTab === 'products' && (
          <ProductsView
            currentSession={currentSession}
            products={products}
            categories={categories}
            loading={loading}
            onRefresh={fetchCatalog}
            onAddCategory={handleAddCategory}
          />
        )}

        {activeTab === 'suppliers' && (
          <SuppliersView
            products={products}
            onRefreshProducts={fetchCatalog}
            userRole={currentSession?.role}
          />
        )}

        {activeTab === 'reports' && <ReportsView currentSession={currentSession} />}

        {activeTab === 'users' && isOwner && <UsersView currentSession={currentSession} />}

        {activeTab === 'settings' && isOwner && <SettingsView currentSession={currentSession} />}

        {activeTab === 'audit' && isOwner && <AuditLogView currentSession={currentSession} />}
      </main>

      {/* Cloud Sync & Backup Modal */}
      <SyncSettingsModal
        isOpen={showSyncModal}
        onClose={() => setShowSyncModal(false)}
        currentSession={currentSession}
      />

      {/* First-Run Setup Wizard */}
      <FirstRunWizardModal
        isOpen={showWizardModal}
        onCompleted={() => {
          setShowWizardModal(false);
          fetchCatalog();
        }}
      />

      {/* Clean Production Footer */}
      <footer className="flex-shrink-0 border-t border-slate-200 bg-white px-6 py-1.5 text-center text-[11px] text-slate-500 font-mono shadow-inner flex items-center justify-between">
        <span>Drawing No. MSP-001 · Mechanical Shop POS · Version 1.0.0</span>
        <span>Offline-First SQLite Engine · Bangladesh</span>
      </footer>
    </div>
  );
}
