import React, { useState, useEffect } from 'react';
import { Supplier, Product, PurchasePayload } from '../../types/ipc';
import {
  Truck,
  Plus,
  Search,
  ShoppingCart,
  DollarSign,
  AlertCircle,
  RefreshCw,
  X,
  Trash2,
} from 'lucide-react';
import { useToast } from '../../context/ToastContext';

interface SuppliersViewProps {
  products: Product[];
  onRefreshProducts: () => void;
  userRole?: 'owner' | 'staff';
}

export const SuppliersView: React.FC<SuppliersViewProps> = ({
  products,
  onRefreshProducts,
  userRole,
}) => {
  const toast = useToast();
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [purchases, setPurchases] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Modals
  const [showSupplierModal, setShowSupplierModal] = useState(false);
  const [supplierName, setSupplierName] = useState('');
  const [supplierPhone, setSupplierPhone] = useState('');
  const [supplierAddress, setSupplierAddress] = useState('');

  const [showPurchaseModal, setShowPurchaseModal] = useState(false);
  const [purchaseSupplierId, setPurchaseSupplierId] = useState('');
  const [purchaseInvoiceRef, setPurchaseInvoiceRef] = useState('');
  const [purchasePaidTaka, setPurchasePaidTaka] = useState('');
  const [purchaseNote, setPurchaseNote] = useState('');
  const [purchaseItems, setPurchaseItems] = useState<
    Array<{ product_id: string; qty: number; unit_cost_taka: number }>
  >([]);

  const isOwner = userRole === 'owner';

  const fetchSuppliers = async () => {
    if (!window.api) return;
    setLoading(true);
    setError(null);
    try {
      const [sups, purches] = await Promise.all([
        window.api.suppliers.list(),
        window.api.purchases.list(),
      ]);
      setSuppliers(sups);
      setPurchases(purches);
    } catch (err: any) {
      setError(err.message || 'Failed to load suppliers data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSuppliers();
  }, []);

  const handleAddSupplier = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!window.api || !supplierName.trim()) return;

    try {
      await window.api.suppliers.create({
        name: supplierName.trim(),
        phone: supplierPhone.trim() || undefined,
        address: supplierAddress.trim() || undefined,
      });
      toast.success(`Supplier "${supplierName}" added successfully.`);
      setShowSupplierModal(false);
      setSupplierName('');
      setSupplierPhone('');
      setSupplierAddress('');
      fetchSuppliers();
    } catch (err: any) {
      toast.error(`Failed to add supplier: ${err.message}`);
    }
  };

  const handleAddPurchaseItem = (productId: string) => {
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;

    setPurchaseItems((prev) => {
      const existing = prev.find((i) => i.product_id === productId);
      if (existing) {
        return prev.map((i) =>
          i.product_id === productId ? { ...i, qty: i.qty + 1 } : i
        );
      } else {
        return [
          ...prev,
          {
            product_id: productId,
            qty: 10,
            unit_cost_taka: prod.cost_price_paisa / 100,
          },
        ];
      }
    });
  };

  const handlePurchaseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!window.api || purchaseItems.length === 0) {
      toast.warning('Please add at least one product to the purchase order.');
      return;
    }

    try {
      const payload: PurchasePayload = {
        supplier_id: purchaseSupplierId || null,
        invoice_ref: purchaseInvoiceRef.trim() || null,
        paid_taka: parseFloat(purchasePaidTaka) || 0,
        note: purchaseNote.trim() || null,
        items: purchaseItems,
      };

      await window.api.purchases.create(payload);
      toast.success('Purchase recorded successfully! Inventory stock and cost price updated.');
      setShowPurchaseModal(false);
      setPurchaseItems([]);
      setPurchasePaidTaka('');
      setPurchaseInvoiceRef('');
      setPurchaseNote('');
      fetchSuppliers();
      onRefreshProducts();
    } catch (err: any) {
      toast.error(`Failed to record purchase: ${err.message}`);
    }
  };

  const filteredSuppliers = suppliers.filter((s) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return s.name.toLowerCase().includes(q) || (s.phone && s.phone.includes(q));
  });

  return (
    <div className="space-y-6 text-slate-900">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 bg-white border border-slate-200 p-4 rounded-2xl shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-sky-50 text-sky-600 rounded-xl border border-sky-200">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">Suppliers & Purchase Invoices</h2>
            <p className="text-xs text-slate-500">Manage vendors, purchase orders, and payable ledgers</p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {isOwner && (
            <>
              <button
                onClick={() => setShowSupplierModal(true)}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-slate-300 transition-colors"
              >
                <Plus className="w-4 h-4 text-sky-600" />
                <span>Add Supplier</span>
              </button>

              <button
                onClick={() => setShowPurchaseModal(true)}
                className="px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md transition-colors"
              >
                <ShoppingCart className="w-4 h-4" />
                <span>New Purchase Invoice</span>
              </button>
            </>
          )}

          <button
            onClick={fetchSuppliers}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl border border-slate-300 transition-colors"
            title="Reload"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Suppliers Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {filteredSuppliers.map((supplier) => (
          <div
            key={supplier.id}
            className="bg-white border border-slate-200 p-4 rounded-2xl shadow-sm flex flex-col justify-between space-y-3"
          >
            <div>
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-bold text-sm text-slate-900">{supplier.name}</h3>
                <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-slate-200">
                  ID: {supplier.id.slice(0, 6)}
                </span>
              </div>
              <p className="text-xs text-slate-600 font-mono">{supplier.phone || 'No phone'}</p>
              {supplier.address && <p className="text-xs text-slate-500 mt-1">{supplier.address}</p>}
            </div>

            <div className="pt-2 border-t border-slate-100 flex items-center justify-between font-mono">
              <span className="text-xs text-slate-500 font-sans">Total Payable:</span>
              <span
                className={`font-bold text-xs ${
                  supplier.total_payable_paisa > 0 ? 'text-amber-700' : 'text-emerald-700'
                }`}
              >
                ৳ {(supplier.total_payable_paisa / 100).toFixed(2)}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Purchases List */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
        <div className="p-3.5 border-b border-slate-200 bg-slate-50 flex justify-between items-center text-xs">
          <span className="font-bold text-slate-800">Purchase Invoices History</span>
          <span className="font-mono text-slate-500">{purchases.length} invoices recorded</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100 text-slate-600 uppercase font-mono text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3">Date</th>
                <th className="p-3">Supplier</th>
                <th className="p-3">Ref Invoice</th>
                <th className="p-3 text-right">Total (৳)</th>
                <th className="p-3 text-right">Paid (৳)</th>
                <th className="p-3">Note</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
              {purchases.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-500 font-sans">
                    No purchase history found.
                  </td>
                </tr>
              ) : (
                purchases.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-3 text-slate-600">{new Date(p.created_at).toLocaleDateString()}</td>
                    <td className="p-3 font-sans text-slate-900 font-bold">{p.supplier_name || 'Generic Vendor'}</td>
                    <td className="p-3 text-sky-700 font-bold">{p.invoice_ref || '-'}</td>
                    <td className="p-3 text-right font-bold text-slate-900">৳ {(p.total_paisa / 100).toFixed(2)}</td>
                    <td className="p-3 text-right text-emerald-700 font-bold">৳ {(p.paid_paisa / 100).toFixed(2)}</td>
                    <td className="p-3 font-sans text-slate-500">{p.note || '-'}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Supplier Modal */}
      {showSupplierModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-sm w-full p-6 shadow-2xl text-slate-900 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="text-base font-bold text-slate-900">Add New Supplier</h3>
              <button onClick={() => setShowSupplierModal(false)} className="text-slate-400 hover:text-slate-700 font-bold">
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSupplier} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Supplier / Vendor Name *</label>
                <input
                  type="text"
                  required
                  value={supplierName}
                  onChange={(e) => setSupplierName(e.target.value)}
                  placeholder="e.g. Rahim Spares Importer"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white font-semibold"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Phone Number</label>
                <input
                  type="text"
                  value={supplierPhone}
                  onChange={(e) => setSupplierPhone(e.target.value)}
                  placeholder="01700-000000"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono focus:outline-none focus:border-sky-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Address / Hub</label>
                <input
                  type="text"
                  value={supplierAddress}
                  onChange={(e) => setSupplierAddress(e.target.value)}
                  placeholder="e.g. Nawabpur, Dhaka"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowSupplierModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl shadow-md transition-colors"
                >
                  Save Supplier
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Purchase Modal */}
      {showPurchaseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-2xl w-full p-6 shadow-2xl text-slate-900 my-8 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <h3 className="text-base font-bold text-slate-900">Record New Purchase Invoice</h3>
              <button onClick={() => setShowPurchaseModal(false)} className="text-slate-400 hover:text-slate-700 font-bold">
                ✕
              </button>
            </div>

            <form onSubmit={handlePurchaseSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Supplier</label>
                  <select
                    value={purchaseSupplierId}
                    onChange={(e) => setPurchaseSupplierId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white"
                  >
                    <option value="">-- Generic / Spot Vendor --</option>
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Vendor Invoice / Challan Ref</label>
                  <input
                    type="text"
                    value={purchaseInvoiceRef}
                    onChange={(e) => setPurchaseInvoiceRef(e.target.value)}
                    placeholder="e.g. CHAL-8892"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono focus:outline-none focus:border-sky-500 focus:bg-white"
                  />
                </div>
              </div>

              {/* Items Picker */}
              <div className="space-y-2">
                <label className="block text-slate-700 font-semibold">Select Products to Add:</label>
                <select
                  onChange={(e) => {
                    if (e.target.value) {
                      handleAddPurchaseItem(e.target.value);
                      e.target.value = '';
                    }
                  }}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white font-semibold"
                >
                  <option value="">-- Click to choose product --</option>
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.barcode}) - Current Cost: ৳{(p.cost_price_paisa / 100).toFixed(2)}
                    </option>
                  ))}
                </select>
              </div>

              {/* Items Table */}
              <div className="border border-slate-200 rounded-xl overflow-hidden bg-slate-50 max-h-44 overflow-y-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-600 font-mono text-[10px] uppercase border-b border-slate-200">
                    <tr>
                      <th className="p-2.5">Product</th>
                      <th className="p-2.5 text-center">Qty</th>
                      <th className="p-2.5 text-right">Unit Cost (৳)</th>
                      <th className="p-2.5 text-right">Total (৳)</th>
                      <th className="p-2.5 text-center">Del</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                    {purchaseItems.map((item, idx) => {
                      const prod = products.find((p) => p.id === item.product_id);
                      return (
                        <tr key={idx} className="hover:bg-white transition-colors">
                          <td className="p-2.5 font-sans font-semibold text-slate-900">{prod?.name}</td>
                          <td className="p-2.5 text-center">
                            <input
                              type="number"
                              min="1"
                              value={item.qty}
                              onChange={(e) => {
                                const val = parseInt(e.target.value, 10) || 1;
                                setPurchaseItems((prev) =>
                                  prev.map((it, i) => (i === idx ? { ...it, qty: val } : it))
                                );
                              }}
                              className="w-16 bg-white border border-slate-300 rounded px-1.5 py-0.5 text-center text-slate-900 font-bold"
                            />
                          </td>
                          <td className="p-2.5 text-right">
                            <input
                              type="number"
                              min="0"
                              step="0.01"
                              value={item.unit_cost_taka}
                              onChange={(e) => {
                                const val = parseFloat(e.target.value) || 0;
                                setPurchaseItems((prev) =>
                                  prev.map((it, i) => (i === idx ? { ...it, unit_cost_taka: val } : it))
                                );
                              }}
                              className="w-20 bg-white border border-slate-300 rounded px-1.5 py-0.5 text-right text-slate-900 font-bold"
                            />
                          </td>
                          <td className="p-2.5 text-right font-bold text-slate-900">
                            ৳ {(item.qty * item.unit_cost_taka).toFixed(2)}
                          </td>
                          <td className="p-2.5 text-center">
                            <button
                              type="button"
                              onClick={() =>
                                setPurchaseItems((prev) => prev.filter((_, i) => i !== idx))
                              }
                              className="text-slate-400 hover:text-rose-600"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Payment Row */}
              <div className="grid grid-cols-2 gap-3 font-mono">
                <div>
                  <label className="block text-slate-700 font-sans font-semibold mb-1">Paid Amount (৳)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={purchasePaidTaka}
                    onChange={(e) => setPurchasePaidTaka(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:border-sky-500 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-sans font-semibold mb-1">Internal Note</label>
                  <input
                    type="text"
                    value={purchaseNote}
                    onChange={(e) => setPurchaseNote(e.target.value)}
                    placeholder="e.g. Paid in full via Bank"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-sans focus:outline-none focus:border-sky-500 focus:bg-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setShowPurchaseModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl shadow-md transition-colors"
                >
                  Save & Update Inventory
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
