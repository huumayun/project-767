import React, { useState, useEffect } from 'react';
import { AppSettings, UserSession } from '../../types/ipc';
import {
  Settings,
  Store,
  Printer,
  Shield,
  Clock,
  Save,
  CheckCircle2,
  AlertCircle,
  Database,
  Cloud,
} from 'lucide-react';
import { useToast } from '../../context/ToastContext';
import { ConfirmModal } from '../common/ConfirmModal';

interface SettingsViewProps {
  currentSession: UserSession | null;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ currentSession }) => {
  const toast = useToast();
  const [shopName, setShopName] = useState('');
  const [shopAddress, setShopAddress] = useState('');
  const [shopPhone, setShopPhone] = useState('');
  const [invoiceFooter, setInvoiceFooter] = useState('');
  const [deviceIdPrefix, setDeviceIdPrefix] = useState('');
  const [defaultInvoiceLayout, setDefaultInvoiceLayout] = useState<'80mm' | 'a5'>('80mm');
  const [idleLockMinutes, setIdleLockMinutes] = useState('15');

  const [loading, setLoading] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const isOwner = currentSession?.role === 'owner';

  const fetchSettings = async () => {
    if (!window.api) return;
    setLoading(true);
    setError(null);
    try {
      const s = await window.api.settings.get();
      setShopName(s.shop_name || '');
      setShopAddress(s.shop_address || '');
      setShopPhone(s.shop_phone || '');
      setInvoiceFooter(s.invoice_footer || '');
      setDeviceIdPrefix(s.device_id_prefix || 'REG01');
      setDefaultInvoiceLayout((s.default_invoice_layout as any) || '80mm');
      setIdleLockMinutes((s.idle_lock_minutes || 15).toString());
    } catch (err: any) {
      setError(err.message || 'Failed to load settings.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!window.api || !isOwner) return;

    setLoading(true);
    setError(null);
    setSavedSuccess(false);
    try {
      await window.api.settings.update({
        shop_name: shopName.trim(),
        shop_address: shopAddress.trim(),
        shop_phone: shopPhone.trim(),
        invoice_footer: invoiceFooter.trim(),
        device_id_prefix: deviceIdPrefix.trim() || 'REG01',
        default_invoice_layout: defaultInvoiceLayout,
        idle_lock_minutes: parseInt(idleLockMinutes, 10) || 15,
      });
      setSavedSuccess(true);
      toast.success('Shop configuration saved successfully.');
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to save settings.');
      toast.error(err.message || 'Failed to update settings.');
    } finally {
      setLoading(false);
    }
  };

  const handleSeedDemo = async () => {
    if (!window.api) return;
    try {
      await window.api.demo.seed();
      toast.success('10 Sample mechanical parts & customers loaded successfully!');
      setTimeout(() => window.location.reload(), 1000);
    } catch (err: any) {
      toast.error(`Failed to seed demo data: ${err.message}`);
    }
  };

  const handleResetDatabase = async () => {
    if (!window.api) return;
    try {
      await window.api.demo.reset();
      toast.success('Database reset to clean state successfully!');
      setTimeout(() => window.location.reload(), 1000);
    } catch (err: any) {
      toast.error(`Reset failed: ${err.message}`);
    }
  };

  if (!isOwner) {
    return (
      <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center text-slate-500 space-y-2 shadow-sm">
        <Shield className="w-12 h-12 mx-auto text-amber-500" />
        <h3 className="text-base font-bold text-slate-900">Owner Authorization Required</h3>
        <p className="text-xs text-slate-500 max-w-sm mx-auto">
          Shop settings and printer configuration are restricted to the Owner.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl text-slate-900">
      <div className="flex items-center justify-between flex-wrap gap-4 bg-white border border-slate-200 p-4 rounded-2xl shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-sky-50 text-sky-600 rounded-xl border border-sky-200">
            <Settings className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">System & Shop Settings</h2>
            <p className="text-xs text-slate-500">Configure store branding, receipt formats, and security rules</p>
          </div>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-2 bg-emerald-50 text-emerald-800 border border-emerald-300 px-3 py-1.5 rounded-xl text-xs font-semibold">
            <CheckCircle2 className="w-4 h-4" />
            <span>Settings Saved Successfully!</span>
          </div>
        )}
      </div>

      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-6 text-xs">
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <Store className="w-4 h-4 text-sky-600" />
            <h3 className="font-bold text-sm text-slate-900">Store Profile & Invoice Header</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Shop / Workshop Name *</label>
              <input
                type="text"
                required
                value={shopName}
                onChange={(e) => setShopName(e.target.value)}
                placeholder="e.g. Master Auto Parts & Mechanical Works"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white font-semibold"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Phone Numbers (Comma separated)</label>
              <input
                type="text"
                value={shopPhone}
                onChange={(e) => setShopPhone(e.target.value)}
                placeholder="01711-000000, 01811-000000"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono focus:outline-none focus:border-sky-500 focus:bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Physical Address</label>
            <input
              type="text"
              value={shopAddress}
              onChange={(e) => setShopAddress(e.target.value)}
              placeholder="e.g. 142/A Tejgaon Link Road, Dhaka-1208"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-slate-700 font-semibold mb-1">Invoice Footer Message (English / বাংলা)</label>
            <input
              type="text"
              value={invoiceFooter}
              onChange={(e) => setInvoiceFooter(e.target.value)}
              placeholder="ধন্যবাদ, আবার আসবেন! • Sold goods cannot be returned without receipt."
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white"
            />
          </div>
        </div>

        {/* Printer & Hardware Setup Card */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <Printer className="w-4 h-4 text-sky-600" />
            <h3 className="font-bold text-sm text-slate-900">Printer & Device Configuration</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Default Invoice Layout</label>
              <select
                value={defaultInvoiceLayout}
                onChange={(e) => setDefaultInvoiceLayout(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white font-semibold"
              >
                <option value="80mm">80mm Thermal Receipt (POS Roll)</option>
                <option value="a5">A5 Formal Invoice (Half-Page Voucher)</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">POS Device / Counter Prefix</label>
              <input
                type="text"
                value={deviceIdPrefix}
                onChange={(e) => setDeviceIdPrefix(e.target.value.toUpperCase())}
                placeholder="REG01"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono font-bold focus:outline-none focus:border-sky-500 focus:bg-white uppercase"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">
                Used in unique invoice numbering: INV-{deviceIdPrefix}-YYYYMMDD-XXXX
              </span>
            </div>
          </div>
        </div>

        {/* Security & Inactivity Lock Card */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <Clock className="w-4 h-4 text-sky-600" />
            <h3 className="font-bold text-sm text-slate-900">Security & Session Policies</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Auto-Lock Inactivity Period (Minutes)</label>
              <input
                type="number"
                min="1"
                max="120"
                value={idleLockMinutes}
                onChange={(e) => setIdleLockMinutes(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono font-bold focus:outline-none focus:border-sky-500 focus:bg-white"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">
                Automatically switches to locked state when idle.
              </span>
            </div>
          </div>
        </div>

        {/* Demo Data & Database Reset Tools */}
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
            <Database className="w-4 h-4 text-purple-600" />
            <h3 className="font-bold text-sm text-slate-900">Database Tools & Sample Data</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
              <span className="font-bold text-slate-800 block">Sample Demo Data</span>
              <p className="text-slate-500 text-[11px]">
                Populates 10 automotive mechanical parts with barcodes, Bengali names, and 3 workshop customers.
              </p>
              <button
                type="button"
                onClick={handleSeedDemo}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs shadow-sm transition-colors"
              >
                Load Sample Mechanical Data
              </button>
            </div>

            <div className="bg-rose-50 p-4 rounded-xl border border-rose-200 space-y-2">
              <span className="font-bold text-rose-900 block">Reset Database (Clean Slate)</span>
              <p className="text-rose-700 text-[11px]">
                Clears all sales, inventory, and ledger history for live production store setup.
              </p>
              <button
                type="button"
                onClick={() => setShowResetConfirm(true)}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs shadow-sm transition-colors"
              >
                Reset Database to Clean Slate
              </button>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl text-xs flex items-center gap-2 shadow-md shadow-sky-600/20 transition-all"
          >
            <Save className="w-4 h-4" />
            <span>{loading ? 'Saving...' : 'Save Changes'}</span>
          </button>
        </div>
      </form>

      {/* Database Reset Confirm Modal */}
      <ConfirmModal
        isOpen={showResetConfirm}
        title="Reset Entire Database"
        message="DANGER: This action will permanently erase all catalog products, transactions, and customer ledgers to start completely clean. Are you sure you want to proceed?"
        isDanger
        confirmLabel="Erase & Reset Clean"
        onConfirm={() => {
          setShowResetConfirm(false);
          handleResetDatabase();
        }}
        onCancel={() => setShowResetConfirm(false)}
      />
    </div>
  );
};
