import React, { useState, useEffect } from 'react';
import { Product } from '../../types/ipc';
import { X, PackagePlus, ArrowRight, Save, AlertCircle } from 'lucide-react';

interface StockInModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  product: Product | null;
}

export const StockInModal: React.FC<StockInModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  product,
}) => {
  const [addQty, setAddQty] = useState<string>('1');
  const [reason, setReason] = useState('Stock delivery received');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setAddQty('1');
    setReason('Stock delivery received');
    setError(null);
  }, [product, isOpen]);

  if (!isOpen || !product) return null;

  const currentQty = product.stock_qty || 0;
  const parsedAdd = parseInt(addQty, 10) || 0;
  const newTotal = currentQty + Math.max(0, parsedAdd);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (parsedAdd <= 0) {
      setError('Please enter a positive quantity to add.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      await window.api.products.stockIn({
        product_id: product.id,
        qty: parsedAdd,
        reason: reason.trim() || 'Stock delivery received',
      });
      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to update stock.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-xl max-w-md w-full p-6 shadow-2xl text-slate-100">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg border border-emerald-500/20">
              <PackagePlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Stock-In Entry</h2>
              <p className="text-xs text-slate-400 font-mono">Barcode: {product.barcode}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mb-4 bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs">
          <div className="font-semibold text-slate-200 text-sm">{product.name}</div>
          {product.name_bn && <div className="text-slate-400 font-sans text-xs mt-0.5">{product.name_bn}</div>}
          <div className="text-slate-500 mt-1 flex justify-between">
            <span>Unit: {product.unit}</span>
            <span>Category: {product.category_name || 'Uncategorized'}</span>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-lg border border-slate-800/80">
            <div className="text-center">
              <div className="text-slate-400 text-[11px]">Current Stock</div>
              <div className="text-xl font-bold font-mono text-slate-300">{currentQty}</div>
            </div>
            <ArrowRight className="w-5 h-5 text-slate-600" />
            <div className="text-center">
              <div className="text-slate-400 text-[11px]">Adding</div>
              <div className="text-xl font-bold font-mono text-emerald-400">+{parsedAdd}</div>
            </div>
            <ArrowRight className="w-5 h-5 text-slate-600" />
            <div className="text-center">
              <div className="text-slate-400 text-[11px]">New Stock</div>
              <div className="text-xl font-bold font-mono text-sky-400">{newTotal}</div>
            </div>
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-1">
              Quantity to Add <span className="text-red-400">*</span>
            </label>
            <input
              type="number"
              min="1"
              required
              autoFocus
              value={addQty}
              onChange={(e) => setAddQty(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-100 text-sm font-mono focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-slate-400 font-medium mb-1">
              Reference / Reason
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. New delivery from supplier"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-800 bg-slate-900 hover:bg-slate-800 text-slate-300 font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold flex items-center gap-2 transition-colors shadow-lg shadow-emerald-600/20"
            >
              <Save className="w-4 h-4" />
              {loading ? 'Updating...' : 'Add to Stock'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
