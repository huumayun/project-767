import React, { useState, useEffect } from 'react';
import { Product } from '../../types/ipc';
import { Printer, Barcode as BarcodeIcon, X, Sliders } from 'lucide-react';
import JsBarcode from 'jsbarcode';
import { useToast } from '../../context/ToastContext';

interface BarcodeLabelModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product;
}

export const BarcodeLabelModal: React.FC<BarcodeLabelModalProps> = ({
  isOpen,
  onClose,
  product,
}) => {
  const toast = useToast();
  const [labelCount, setLabelCount] = useState<number>(12);
  const [showPrice, setShowPrice] = useState(true);

  useEffect(() => {
    if (isOpen && product.barcode) {
      setTimeout(() => {
        try {
          JsBarcode('#barcode-preview-canvas', product.barcode!, {
            format: 'CODE128',
            width: 1.5,
            height: 45,
            displayValue: true,
            fontSize: 11,
            margin: 5,
          });
        } catch (err) {
          console.error('Barcode rendering error:', err);
        }
      }, 100);
    }
  }, [isOpen, product]);

  if (!isOpen) return null;

  const handlePrintLabels = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.warning('Please allow popups in your browser to print barcode sheets.');
      return;
    }

    const canvas = document.getElementById('barcode-preview-canvas') as HTMLCanvasElement;
    const barcodeDataUrl = canvas ? canvas.toDataURL('image/png') : '';

    const labelHtml = `
      <div style="border: 1px dashed #ccc; padding: 6px; text-align: center; font-family: sans-serif; width: 180px; page-break-inside: avoid; display: inline-block; margin: 4px; box-sizing: border-box;">
        <div style="font-size: 10px; font-weight: bold; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${product.name}</div>
        <img src="${barcodeDataUrl}" style="max-width: 100%; height: auto;" />
        ${showPrice ? `<div style="font-size: 11px; font-weight: bold; font-family: monospace;">MRP: ৳ ${(product.sell_price_paisa / 100).toFixed(2)}</div>` : ''}
      </div>
    `;

    let sheetHtml = '';
    for (let i = 0; i < labelCount; i++) {
      sheetHtml += labelHtml;
    }

    printWindow.document.write(`
      <html>
        <head>
          <title>Barcode Label Sheet - ${product.barcode}</title>
          <style>
            @page { size: A4; margin: 10mm; }
            body { margin: 0; padding: 0; font-family: sans-serif; display: flex; flex-wrap: wrap; justify-content: flex-start; }
          </style>
        </head>
        <body>
          ${sheetHtml}
          <script>
            window.onload = function() { window.print(); window.close(); }
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 shadow-2xl text-slate-900 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-sky-50 text-sky-600 rounded-xl border border-sky-200 shadow-sm">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Print Barcode Labels</h3>
              <p className="text-xs text-slate-500 font-mono">Code128 Format (A4 Sticker Sheet)</p>
            </div>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 font-bold">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Barcode Preview Card */}
        <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl flex flex-col items-center justify-center space-y-2">
          <span className="font-bold text-xs text-slate-900 text-center">{product.name}</span>
          <canvas id="barcode-preview-canvas" className="bg-white p-2 rounded-lg border border-slate-200 shadow-sm" />
          {showPrice && (
            <span className="font-mono font-bold text-xs text-slate-900">
              MRP: ৳ {(product.sell_price_paisa / 100).toFixed(2)}
            </span>
          )}
        </div>

        {/* Options */}
        <div className="space-y-3 text-xs">
          <div>
            <label className="block text-slate-700 font-semibold mb-1">Number of Labels to Print</label>
            <input
              type="number"
              min="1"
              max="200"
              value={labelCount}
              onChange={(e) => setLabelCount(parseInt(e.target.value, 10) || 1)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono font-bold focus:outline-none focus:border-sky-500 focus:bg-white"
            />
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="showPrice"
              checked={showPrice}
              onChange={(e) => setShowPrice(e.target.checked)}
              className="rounded bg-slate-100 border-slate-300 text-sky-600 focus:ring-0"
            />
            <label htmlFor="showPrice" className="text-slate-700 font-semibold cursor-pointer">
              Print Retail Price (৳) on Label
            </label>
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-3 border-t border-slate-200">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handlePrintLabels}
            className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Print Label Sheet</span>
          </button>
        </div>
      </div>
    </div>
  );
};
