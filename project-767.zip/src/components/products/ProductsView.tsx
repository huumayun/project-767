import React, { useState, useRef } from 'react';
import { Product, Category, UserSession } from '../../types/ipc';
import {
  Package,
  Search,
  Plus,
  Edit2,
  Trash2,
  Printer,
  Upload,
  ArrowDownCircle,
  AlertTriangle,
  RefreshCw,
  SlidersHorizontal,
  Barcode,
  Sparkles,
} from 'lucide-react';
import { ProductFormModal } from './ProductFormModal';
import { BarcodeLabelModal } from './BarcodeLabelModal';
import { CsvImportModal } from './CsvImportModal';

import { useToast } from '../../context/ToastContext';
import { ConfirmModal } from '../common/ConfirmModal';
import { playScanSuccess } from '../../utils/audio';

interface ProductsViewProps {
  currentSession: UserSession | null;
  products: Product[];
  categories: Category[];
  loading: boolean;
  onRefresh: () => void;
  onAddCategory: (name: string) => Promise<Category | null>;
}

export const ProductsView: React.FC<ProductsViewProps> = ({
  currentSession,
  products,
  categories,
  loading,
  onRefresh,
  onAddCategory,
}) => {
  const toast = useToast();
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [showLowStockOnly, setShowLowStockOnly] = useState(false);

  // Quick Barcode Scan State
  const [quickScanInput, setQuickScanInput] = useState('');
  const [initialBarcode, setInitialBarcode] = useState('');
  const quickScanRef = useRef<HTMLInputElement>(null);

  // Modals
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showBarcodeModal, setShowBarcodeModal] = useState(false);
  const [barcodeTargetProduct, setBarcodeTargetProduct] = useState<Product | null>(null);
  const [showCsvModal, setShowCsvModal] = useState(false);

  const [stockInProduct, setStockInProduct] = useState<Product | null>(null);
  const [stockInQty, setStockInQty] = useState<number>(10);
  const [stockInReason, setStockInReason] = useState<string>('Quick Stock-in');
  const [stockInLoading, setStockInLoading] = useState(false);

  // Delete Confirm Modal
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; name: string } | null>(null);

  const isOwner = currentSession?.role === 'owner';

  const filteredProducts = products.filter((p) => {
    if (selectedCategory && p.category_id !== selectedCategory) return false;
    if (showLowStockOnly && p.stock_qty > (p.low_stock_threshold ?? 5)) return false;
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      (p.name_bn && p.name_bn.toLowerCase().includes(q)) ||
      (p.barcode && p.barcode.toLowerCase().includes(q)) ||
      (p.brand && p.brand.toLowerCase().includes(q))
    );
  });

  const confirmDelete = async () => {
    if (!deleteTarget || !window.api || !isOwner) return;
    try {
      await window.api.products.delete(deleteTarget.id);
      toast.success(`Product "${deleteTarget.name}" deleted.`);
      setDeleteTarget(null);
      onRefresh();
    } catch (err: any) {
      toast.error(`Failed to delete product: ${err.message}`);
    }
  };

  const handleQuickScanSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const code = quickScanInput.trim();
    if (!code) return;

    if (!window.api) return;
    try {
      const found = await window.api.products.getByBarcode(code);
      if (found) {
        playScanSuccess();
        toast.info(`প্রোডাক্ট পাওয়া গেছে: "${found.name}" (মজুদ: ${found.stock_qty})`);
        setEditingProduct(found);
        setInitialBarcode('');
        setShowFormModal(true);
      } else {
        playScanSuccess();
        toast.success(`নতুন বারকোড স্ক্যান হয়েছে: ${code}`);
        setEditingProduct(null);
        setInitialBarcode(code);
        setShowFormModal(true);
      }
      setQuickScanInput('');
    } catch (err: any) {
      toast.error(`স্ক্যান এরর: ${err.message}`);
    }
  };

  const handleStockInSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!window.api || !stockInProduct) return;
    setStockInLoading(true);
    try {
      await window.api.products.stockIn({
        product_id: stockInProduct.id,
        qty: stockInQty,
        reason: stockInReason,
      });
      toast.success(`Added ${stockInQty} units to "${stockInProduct.name}".`);
      setStockInProduct(null);
      onRefresh();
    } catch (err: any) {
      toast.error(`Stock in failed: ${err.message}`);
    } finally {
      setStockInLoading(false);
    }
  };

  return (
    <div className="h-full flex-1 flex flex-col overflow-hidden min-h-0 space-y-2.5 text-slate-900">
      {/* Top Header - Fixed */}
      <div className="flex-shrink-0 flex items-center justify-between flex-wrap gap-3 bg-white border border-slate-200 p-3 sm:p-4 rounded-2xl shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-sky-50 text-sky-600 rounded-xl border border-sky-200">
            <Package className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">Product & Inventory Catalog</h2>
            <p className="text-xs text-slate-500">Track stock levels, barcode scanning, labels, and mechanical parts</p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Quick Barcode Scanner Bar */}
          {isOwner && (
            <form onSubmit={handleQuickScanSubmit} className="relative flex items-center">
              <input
                ref={quickScanRef}
                type="text"
                value={quickScanInput}
                onChange={(e) => setQuickScanInput(e.target.value)}
                placeholder="স্ক্যান করুন / বারকোড দিয়ে যোগ..."
                className="bg-sky-50/70 border border-sky-300 rounded-xl pl-8 pr-20 py-1.5 text-xs text-slate-900 font-mono focus:outline-none focus:border-sky-500 focus:bg-white w-52 sm:w-64 placeholder:text-slate-400 placeholder:font-sans"
              />
              <Barcode className="w-4 h-4 text-sky-600 absolute left-2.5 pointer-events-none" />
              <button
                type="submit"
                className="absolute right-1 px-2 py-0.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-[10px] font-bold shadow-sm transition-colors"
              >
                Scan/Add
              </button>
            </form>
          )}

          {isOwner && (
            <>
              <button
                onClick={() => setShowCsvModal(true)}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-slate-300 transition-colors"
              >
                <Upload className="w-4 h-4 text-emerald-600" />
                <span>Bulk CSV</span>
              </button>

              <button
                onClick={() => {
                  setEditingProduct(null);
                  setInitialBarcode('');
                  setShowFormModal(true);
                }}
                className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add Product</span>
              </button>
            </>
          )}

          <button
            onClick={onRefresh}
            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl border border-slate-300 transition-colors"
            title="Reload Products"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Filter / Search Bar - Fixed */}
      <div className="flex-shrink-0 flex items-center gap-3 flex-wrap bg-white border border-slate-200 p-3 rounded-2xl shadow-sm">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by part name, Bengali name, barcode, brand..."
            className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-10 pr-4 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs text-slate-700 focus:outline-none focus:border-sky-500"
          >
            <option value="">All Categories</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <button
            onClick={() => setShowLowStockOnly(!showLowStockOnly)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors border ${
              showLowStockOnly
                ? 'bg-amber-100 text-amber-800 border-amber-300 font-bold'
                : 'bg-slate-50 text-slate-600 border-slate-300 hover:bg-slate-100'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
            <span>Low Stock Alerts</span>
          </button>
        </div>
      </div>

      {/* Products Table - Scrollable Zone */}
      <div className="flex-1 overflow-y-auto min-h-0 bg-white border border-slate-200 rounded-2xl shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100 text-slate-600 uppercase font-mono text-[10px] tracking-wider border-b border-slate-200 sticky top-0 z-10">
              <tr>
                <th className="p-3.5">Barcode</th>
                <th className="p-3.5">Product Name</th>
                <th className="p-3.5">Category</th>
                <th className="p-3.5 text-center">Stock</th>
                {isOwner && <th className="p-3.5 text-right">Cost (৳)</th>}
                <th className="p-3.5 text-right">Sell Price (৳)</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11.5px]">
              {filteredProducts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-12 text-center text-slate-500 font-sans">
                    {loading ? 'Loading catalog...' : 'No products found matching filters.'}
                  </td>
                </tr>
              ) : (
                filteredProducts.map((product) => {
                  const isLow = product.stock_qty <= product.low_stock_threshold;

                  return (
                    <tr key={product.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-3.5 font-bold text-sky-700">{product.barcode}</td>
                      <td className="p-3.5 font-sans">
                        <div className="font-bold text-slate-900">{product.name}</div>
                        {product.name_bn && (
                          <div className="text-[11px] text-slate-500">{product.name_bn}</div>
                        )}
                        {product.brand && (
                          <div className="text-[10px] text-slate-500 font-mono">Brand: {product.brand}</div>
                        )}
                      </td>
                      <td className="p-3.5 font-sans text-slate-600">{product.category_name || '-'}</td>
                      <td className="p-3.5 text-center">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            isLow
                              ? 'bg-amber-100 text-amber-800 border border-amber-300'
                              : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          }`}
                        >
                          {product.stock_qty} {product.unit}
                        </span>
                      </td>
                      {isOwner && (
                        <td className="p-3.5 text-right text-slate-600">
                          ৳ {(product.cost_price_paisa / 100).toFixed(2)}
                        </td>
                      )}
                      <td className="p-3.5 text-right font-bold text-slate-900">
                        ৳ {(product.sell_price_paisa / 100).toFixed(2)}
                      </td>
                      <td className="p-3.5 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setStockInProduct(product)}
                            className="p-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg border border-emerald-200 transition-colors"
                            title="Quick Stock-In"
                          >
                            <ArrowDownCircle className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => {
                              setBarcodeTargetProduct(product);
                              setShowBarcodeModal(true);
                            }}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-300 transition-colors"
                            title="Print Barcode Labels"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>

                          {isOwner && (
                            <>
                              <button
                                onClick={() => {
                                  setEditingProduct(product);
                                  setShowFormModal(true);
                                }}
                                className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-300 transition-colors"
                                title="Edit Product"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>

                              <button
                                onClick={() => setDeleteTarget({ id: product.id, name: product.name })}
                                className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg border border-rose-200 transition-colors"
                                title="Delete Product"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Quick Stock-In Modal */}
      {stockInProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-sm w-full p-6 shadow-2xl text-slate-900 space-y-4">
            <h3 className="text-base font-bold text-slate-900">Quick Stock-In</h3>
            <p className="text-xs text-slate-600 font-sans">
              Add inventory for <strong className="text-sky-700">{stockInProduct.name}</strong> (Current:{' '}
              {stockInProduct.stock_qty} {stockInProduct.unit})
            </p>

            <form onSubmit={handleStockInSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Quantity to Add</label>
                <input
                  type="number"
                  required
                  min="1"
                  value={stockInQty}
                  onChange={(e) => setStockInQty(parseInt(e.target.value, 10) || 1)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono font-bold focus:outline-none focus:border-sky-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Note / Reference</label>
                <input
                  type="text"
                  value={stockInReason}
                  onChange={(e) => setStockInReason(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setStockInProduct(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={stockInLoading}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md transition-colors"
                >
                  {stockInLoading ? 'Adding...' : 'Confirm Stock-In'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {showFormModal && (
        <ProductFormModal
          isOpen={showFormModal}
          onClose={() => {
            setShowFormModal(false);
            setEditingProduct(null);
            setInitialBarcode('');
          }}
          product={editingProduct}
          initialBarcode={initialBarcode}
          categories={categories}
          onSuccess={() => {
            onRefresh();
            setShowFormModal(false);
            setEditingProduct(null);
            setInitialBarcode('');
          }}
          onAddCategory={onAddCategory}
          onSelectExistingProduct={(prod) => {
            setEditingProduct(prod);
            setInitialBarcode('');
          }}
        />
      )}

      {/* Barcode Label Print Modal */}
      {showBarcodeModal && barcodeTargetProduct && (
        <BarcodeLabelModal
          isOpen={showBarcodeModal}
          onClose={() => {
            setShowBarcodeModal(false);
            setBarcodeTargetProduct(null);
          }}
          product={barcodeTargetProduct}
        />
      )}

      {/* Bulk CSV Import Modal */}
      {showCsvModal && (
        <CsvImportModal
          isOpen={showCsvModal}
          onClose={() => setShowCsvModal(false)}
          onSuccess={() => {
            onRefresh();
            setShowCsvModal(false);
          }}
        />
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={Boolean(deleteTarget)}
        title="Delete Product"
        message={`Are you sure you want to permanently delete product "${deleteTarget?.name}"?`}
        isDanger
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
