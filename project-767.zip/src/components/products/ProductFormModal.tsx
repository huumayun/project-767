import React, { useState, useEffect, useRef } from 'react';
import { Product, Category } from '../../types/ipc';
import { Package, X, Plus, AlertCircle, Save, Barcode, Sparkles, CheckCircle2, ArrowRight, Layers } from 'lucide-react';
import { playScanSuccess, playScanError } from '../../utils/audio';

interface ProductFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  product?: Product | null;
  initialBarcode?: string;
  categories: Category[];
  onSuccess: () => void;
  onAddCategory: (name: string) => Promise<Category | null>;
  onSelectExistingProduct?: (prod: Product) => void;
}

export const ProductFormModal: React.FC<ProductFormModalProps> = ({
  isOpen,
  onClose,
  product,
  initialBarcode = '',
  categories,
  onSuccess,
  onAddCategory,
  onSelectExistingProduct,
}) => {
  const [barcode, setBarcode] = useState('');
  const [name, setName] = useState('');
  const [nameBn, setNameBn] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [brand, setBrand] = useState('');
  const [unit, setUnit] = useState('pcs');
  const [costPriceTaka, setCostPriceTaka] = useState('');
  const [sellPriceTaka, setSellPriceTaka] = useState('');
  const [stockQty, setStockQty] = useState('0');
  const [addStockQty, setAddStockQty] = useState('');
  const [stockAdjustmentNote, setStockAdjustmentNote] = useState('Manual Stock Adjustment');
  const [lowStockThreshold, setLowStockThreshold] = useState('5');
  const [isSerialTracked, setIsSerialTracked] = useState(false);

  const [showAddCatInput, setShowAddCatInput] = useState(false);
  const [newCatName, setNewCatName] = useState('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [existingProductWarning, setExistingProductWarning] = useState<Product | null>(null);

  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const nameInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (product) {
      setBarcode(product.barcode || '');
      setName(product.name || '');
      setNameBn(product.name_bn || '');
      setCategoryId(product.category_id || '');
      setBrand(product.brand || '');
      setUnit(product.unit || 'pcs');
      setCostPriceTaka((product.cost_price_paisa / 100).toString());
      setSellPriceTaka((product.sell_price_paisa / 100).toString());
      setStockQty((product.stock_qty || 0).toString());
      setAddStockQty('');
      setLowStockThreshold((product.low_stock_threshold || 5).toString());
      setIsSerialTracked(Boolean(product.is_serial_tracked));

      setTimeout(() => nameInputRef.current?.focus(), 120);
    } else {
      setBarcode(initialBarcode || '');
      setName('');
      setNameBn('');
      setCategoryId('');
      setBrand('');
      setUnit('pcs');
      setCostPriceTaka('');
      setSellPriceTaka('');
      setStockQty('0');
      setAddStockQty('');
      setLowStockThreshold('5');
      setIsSerialTracked(false);

      if (initialBarcode) {
        setTimeout(() => nameInputRef.current?.focus(), 120);
      } else {
        setTimeout(() => barcodeInputRef.current?.focus(), 120);
      }
    }
    setExistingProductWarning(null);
    setError(null);
  }, [product, initialBarcode, isOpen]);

  // Live duplicate barcode checker on typing debounce
  useEffect(() => {
    if (!barcode.trim() || (product && product.barcode === barcode.trim())) {
      setExistingProductWarning(null);
      return;
    }

    const timer = setTimeout(async () => {
      if (!window.api) return;
      try {
        const found = await window.api.products.getByBarcode(barcode.trim());
        if (found && (!product || found.id !== product.id)) {
          setExistingProductWarning(found);
        } else {
          setExistingProductWarning(null);
        }
      } catch (err) {
        setExistingProductWarning(null);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [barcode, product]);

  const handleBarcodeKeyDown = async (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault(); // Stop premature form submission by hardware scanner
      const code = barcode.trim();
      if (!code) return;

      if (!window.api) {
        nameInputRef.current?.focus();
        return;
      }

      try {
        const found = await window.api.products.getByBarcode(code);
        if (found && (!product || found.id !== product.id)) {
          playScanError();
          setExistingProductWarning(found);
        } else {
          playScanSuccess();
          setExistingProductWarning(null);
          nameInputRef.current?.focus();
        }
      } catch (err) {
        nameInputRef.current?.focus();
      }
    }
  };

  const handleGenerateBarcode = () => {
    const randomCode = 'MSP' + Math.floor(10000000 + Math.random() * 90000000);
    setBarcode(randomCode);
    playScanSuccess();
    setTimeout(() => nameInputRef.current?.focus(), 100);
  };

  if (!isOpen) return null;

  const handleCreateCategory = async () => {
    if (!newCatName.trim()) return;
    const cat = await onAddCategory(newCatName.trim());
    if (cat) {
      setCategoryId(cat.id);
      setNewCatName('');
      setShowAddCatInput(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!window.api) return;

    const costPaisa = Math.round((parseFloat(costPriceTaka) || 0) * 100);
    const sellPaisa = Math.round((parseFloat(sellPriceTaka) || 0) * 100);
    const stock = parseInt(stockQty, 10) || 0;
    const threshold = parseInt(lowStockThreshold, 10) || 5;

    if (sellPaisa < 0 || costPaisa < 0) {
      setError('Prices cannot be negative.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      if (product) {
        await window.api.products.update({
          id: product.id,
          barcode: barcode.trim() || null,
          name: name.trim(),
          name_bn: nameBn.trim() || null,
          category_id: categoryId || null,
          brand: brand.trim() || null,
          unit,
          cost_price_paisa: costPaisa,
          sell_price_paisa: sellPaisa,
          low_stock_threshold: threshold,
          is_serial_tracked: isSerialTracked,
        });

        // Handle Stock-in or Direct Stock Adjustment
        const added = parseInt(addStockQty, 10);
        if (!isNaN(added) && added > 0) {
          await window.api.products.stockIn({
            product_id: product.id,
            qty: added,
            reason: stockAdjustmentNote || 'Restock via Edit Product',
          });
        } else {
          const newTotal = parseInt(stockQty, 10);
          const originalStock = product.stock_qty || 0;
          if (!isNaN(newTotal) && newTotal !== originalStock) {
            const delta = newTotal - originalStock;
            if (delta > 0) {
              await window.api.products.stockIn({
                product_id: product.id,
                qty: delta,
                reason: 'Direct Stock Adjustment',
              });
            } else if (delta < 0) {
              await window.api.products.stockAdjustment({
                product_id: product.id,
                qty_delta: delta,
                reason: 'Direct Stock Adjustment',
              });
            }
          }
        }
      } else {
        await window.api.products.create({
          barcode: barcode.trim() || null,
          name: name.trim(),
          name_bn: nameBn.trim() || null,
          category_id: categoryId || null,
          brand: brand.trim() || null,
          unit,
          cost_price_paisa: costPaisa,
          sell_price_paisa: sellPaisa,
          stock_qty: stock,
          low_stock_threshold: threshold,
          is_serial_tracked: isSerialTracked,
        });
      }
      onSuccess();
    } catch (err: any) {
      setError(err.message || 'Failed to save product.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-6 shadow-2xl text-slate-900 my-8 space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-sky-50 text-sky-600 rounded-xl border border-sky-200 shadow-sm">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {product ? 'Edit Mechanical Part' : 'Add New Product'}
              </h3>
              <p className="text-xs text-slate-500 font-mono">
                {product ? `ID: ${product.id.slice(0, 8)}` : 'Create inventory record'}
              </p>
            </div>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 font-bold">
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {existingProductWarning && (
          <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-amber-900 text-xs flex items-center justify-between gap-2 shadow-sm">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0" />
              <div>
                <span className="font-bold">এই বারকোডটি ইতিমধ্যে ব্যবহৃত:</span> {existingProductWarning.name} (মজুদ: {existingProductWarning.stock_qty} {existingProductWarning.unit})
              </div>
            </div>
            {onSelectExistingProduct && (
              <button
                type="button"
                onClick={() => onSelectExistingProduct(existingProductWarning)}
                className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-[11px] flex items-center gap-1 flex-shrink-0"
              >
                <span>এডিট করুন</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {/* Barcode & Brand */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-slate-700 font-semibold">
                  Barcode / বারকোড
                </label>
                {!product && (
                  <button
                    type="button"
                    onClick={handleGenerateBarcode}
                    className="text-sky-600 hover:text-sky-800 text-[11px] font-semibold flex items-center gap-1 hover:underline"
                    title="Generate unique internal barcode"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Auto Generate</span>
                  </button>
                )}
              </div>
              <div className="relative">
                <input
                  ref={barcodeInputRef}
                  type="text"
                  value={barcode}
                  onChange={(e) => setBarcode(e.target.value)}
                  onKeyDown={handleBarcodeKeyDown}
                  placeholder="স্ক্যান করুন বা বারকোড লিখুন"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2 text-slate-900 font-mono focus:outline-none focus:border-sky-500 focus:bg-white font-bold"
                />
                <Barcode className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Brand / Manufacturer</label>
              <input
                type="text"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
                placeholder="e.g. Bosch, NGK, Denso"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white"
              />
            </div>
          </div>

          {/* Name & Bangla Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Product Name (English) *</label>
              <input
                ref={nameInputRef}
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Spark Plug Iridium"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white font-semibold"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Product Name (বাংলা)</label>
              <input
                type="text"
                value={nameBn}
                onChange={(e) => setNameBn(e.target.value)}
                placeholder="যেমন: স্পার্ক প্লাগ"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white"
              />
            </div>
          </div>

          {/* Category & Unit */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="block text-slate-700 font-semibold">Category</label>
                <button
                  type="button"
                  onClick={() => setShowAddCatInput(!showAddCatInput)}
                  className="text-[11px] text-sky-700 hover:underline flex items-center gap-0.5 font-bold"
                >
                  <Plus className="w-3 h-3" /> New
                </button>
              </div>

              {showAddCatInput ? (
                <div className="flex items-center gap-1">
                  <input
                    type="text"
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    placeholder="New category..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-sky-500"
                  />
                  <button
                    type="button"
                    onClick={handleCreateCategory}
                    className="px-2.5 py-1.5 bg-sky-600 text-white rounded-xl font-bold"
                  >
                    Save
                  </button>
                </div>
              ) : (
                <select
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white"
                >
                  <option value="">-- Uncategorized --</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div>
              <label className="block text-slate-700 font-semibold mb-1">Unit of Measure</label>
              <select
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white"
              >
                <option value="pcs">Pieces (Pcs)</option>
                <option value="set">Set</option>
                <option value="box">Box</option>
                <option value="kg">Kilogram (Kg)</option>
                <option value="ltr">Liter (Ltr)</option>
                <option value="pair">Pair</option>
              </select>
            </div>
          </div>

          {/* Pricing & Stock */}
          <div className={`grid gap-3 font-mono ${product ? 'grid-cols-3' : 'grid-cols-2 sm:grid-cols-4'}`}>
            <div>
              <label className="block text-slate-700 font-sans font-semibold mb-1">Cost Price (৳) *</label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={costPriceTaka}
                onChange={(e) => setCostPriceTaka(e.target.value)}
                placeholder="0.00"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white font-bold"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-sans font-semibold mb-1">Sell Price (৳) *</label>
              <input
                type="number"
                required
                min="0"
                step="0.01"
                value={sellPriceTaka}
                onChange={(e) => setSellPriceTaka(e.target.value)}
                placeholder="0.00"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white font-bold"
              />
            </div>

            {!product && (
              <div>
                <label className="block text-slate-700 font-sans font-semibold mb-1">Initial Stock (প্রাথমিক স্টক)</label>
                <input
                  type="number"
                  min="0"
                  value={stockQty}
                  onChange={(e) => setStockQty(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white font-bold"
                />
              </div>
            )}

            <div>
              <label className="block text-slate-700 font-sans font-semibold mb-1">Low Stock Alert</label>
              <input
                type="number"
                min="1"
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white font-bold"
              />
            </div>
          </div>

          {/* Dedicated Stock Management & Restock Box (When Editing) */}
          {product && (
            <div className="bg-sky-50/70 border border-sky-200 p-3.5 rounded-2xl space-y-2.5 shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 bg-sky-100 text-sky-700 rounded-lg">
                    <Layers className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-slate-900 text-xs">ইনভেন্টরি ও স্টক আপডেট (Stock Management)</span>
                </div>
                <div className="text-xs font-mono">
                  <span className="text-slate-500">বর্তমান স্টক: </span>
                  <span className="font-extrabold text-sky-800 bg-white px-2 py-0.5 rounded-lg border border-sky-300">
                    {product.stock_qty || 0} {unit}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    নতুন স্টক যোগ করুন (+Qty)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="0"
                      value={addStockQty}
                      onChange={(e) => setAddStockQty(e.target.value)}
                      placeholder="যেমন: ১০ টি মাল ঢুকলে 10 লিখুন"
                      className="w-full bg-white border border-sky-300 rounded-xl pl-8 pr-3 py-2 text-slate-900 font-mono font-bold focus:outline-none focus:border-sky-500"
                    />
                    <Plus className="w-4 h-4 text-sky-600 absolute left-2.5 top-2.5 pointer-events-none" />
                  </div>
                  {parseInt(addStockQty, 10) > 0 && (
                    <span className="text-[11px] text-emerald-700 font-semibold mt-1 block">
                      ✓ সেভ করলে নতুন মোট স্টক হবে: {(product.stock_qty || 0) + parseInt(addStockQty, 10)} {unit}
                    </span>
                  )}
                </div>

                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    অথবা সরাসরি মোট স্টক পরিবর্তন
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={stockQty}
                    onChange={(e) => setStockQty(e.target.value)}
                    placeholder="মোট সংখ্যা..."
                    className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-mono font-bold focus:outline-none focus:border-sky-500"
                  />
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    ইনভেন্টরি অডিট বা সরাসরি সংখ্যা সংশোধনের জন্য
                  </span>
                </div>
              </div>
            </div>
          )}

          <div className="flex items-center gap-2 pt-1">
            <input
              type="checkbox"
              id="isSerial"
              checked={isSerialTracked}
              onChange={(e) => setIsSerialTracked(e.target.checked)}
              className="rounded bg-slate-100 border-slate-300 text-sky-600 focus:ring-0"
            />
            <label htmlFor="isSerial" className="text-slate-700 font-semibold cursor-pointer">
              Serial Number Tracking (For batteries, high-value components)
            </label>
          </div>

          <div className="flex justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl shadow-md transition-colors"
            >
              {loading ? 'Saving...' : product ? 'Update Product' : 'Create Product'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
