import React, { useEffect, useState } from 'react';
import { Product, UserSession } from '../../types/ipc';
import {
  TrendingUp,
  Wallet,
  AlertTriangle,
  Users,
  ShoppingCart,
  ArrowRight,
  Package,
  PlusCircle,
  BarChart3,
  Calendar,
  DollarSign,
  Receipt,
  Truck,
} from 'lucide-react';
import { Language, translations } from '../../i18n/translations';

interface DashboardViewProps {
  currentSession: UserSession | null;
  products: Product[];
  onNavigateTab: (tab: 'pos' | 'sales' | 'customers' | 'products' | 'suppliers' | 'reports' | 'dashboard') => void;
  lang: Language;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  currentSession,
  products,
  onNavigateTab,
  lang,
}) => {
  const [dailySalesPaisa, setDailySalesPaisa] = useState(0);
  const [dailyCashPaisa, setDailyCashPaisa] = useState(0);
  const [dailyDuePaisa, setDailyDuePaisa] = useState(0);
  const [dailyInvoicesCount, setDailyInvoicesCount] = useState(0);
  const [totalCustomerDuePaisa, setTotalCustomerDuePaisa] = useState(0);
  const [customersWithDueCount, setCustomersWithDueCount] = useState(0);
  const [totalCustomersCount, setTotalCustomersCount] = useState(0);
  const [recentSales, setRecentSales] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const t = translations[lang];

  useEffect(() => {
    const fetchDashboardData = async () => {
      if (!window.api) return;
      setLoading(true);
      try {
        const todayStr = new Date().toISOString().slice(0, 10);
        const [report, dueSummary, customersList, salesList] = await Promise.all([
          window.api.reports.getSalesReport({ startDate: todayStr, endDate: todayStr }).catch(() => null),
          window.api.customers.getDueSummary().catch(() => null),
          window.api.customers.list().catch(() => []),
          window.api.sales.list(6).catch(() => []),
        ]);

        if (report) {
          setDailySalesPaisa(report.net_sales_paisa || report.gross_sales_paisa || 0);
          setDailyCashPaisa(report.payments_breakdown?.cash_paisa || 0);
          const nonCash = (report.payments_breakdown?.bkash_paisa || 0) + (report.payments_breakdown?.nagad_paisa || 0) + (report.payments_breakdown?.card_paisa || 0);
          setDailyDuePaisa(Math.max(0, (report.net_sales_paisa || 0) - (report.payments_breakdown?.cash_paisa || 0) - nonCash));
          setDailyInvoicesCount(report.total_orders || 0);
        }

        if (dueSummary) {
          setTotalCustomerDuePaisa(dueSummary.total_due_paisa || 0);
          setCustomersWithDueCount(dueSummary.customers_with_due_count || 0);
        }

        if (customersList) {
          setTotalCustomersCount(customersList.length);
        }

        if (salesList) {
          setRecentSales(salesList);
        }
      } catch (err) {
        console.error('Failed to load dashboard metrics:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const lowStockProducts = products.filter((p) => p.stock_qty <= (p.low_stock_threshold ?? 5));

  return (
    <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-6 bg-slate-100 font-sans">
      {/* Top Welcome & KPI Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <span>{lang === 'bn' ? 'দোকানের ড্যাশবোর্ড ও সংক্ষিপ্ত হিসাব' : 'Shop Overview & Daily Summary'}</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 font-mono flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-sky-600" />
            <span>
              {new Date().toLocaleDateString(lang === 'bn' ? 'bn-BD' : 'en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </span>
          </p>
        </div>

        {/* Quick Sale CTA */}
        <button
          onClick={() => onNavigateTab('pos')}
          className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-sky-600 to-sky-500 hover:from-sky-500 hover:to-sky-400 text-white font-bold px-5 py-2.5 rounded-xl shadow-md shadow-sky-600/20 text-xs transition-all active:scale-95"
        >
          <ShoppingCart className="w-4 h-4" />
          <span>{lang === 'bn' ? 'নতুন বিক্রি শুরু করুন (POS)' : 'Launch POS Terminal'}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Today's Sales */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 font-sans">{t.todaySales}</span>
            <div className="p-2 bg-emerald-50 text-emerald-600 rounded-xl">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-extrabold text-slate-900 font-mono">
              ৳ {(dailySalesPaisa / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 font-sans">
              {dailyInvoicesCount} {lang === 'bn' ? 'টি মেমো কাটা হয়েছে' : 'invoices completed'}
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-emerald-500" />
        </div>

        {/* Cash Collected Today */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 font-sans">{lang === 'bn' ? 'আজকের নগদ জমা' : 'Cash Collected'}</span>
            <div className="p-2 bg-sky-50 text-sky-600 rounded-xl">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-extrabold text-slate-900 font-mono">
              ৳ {(dailyCashPaisa / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 font-sans">
              {lang === 'bn' ? 'ক্যাশ বক্সে সরাসরি জমা' : 'Direct cash in register'}
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-sky-500" />
        </div>

        {/* Total Outstanding Customer Due */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 font-sans">{lang === 'bn' ? 'মোট বকেয়া পাওনা' : 'Outstanding Due'}</span>
            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-extrabold text-amber-700 font-mono">
              ৳ {(totalCustomerDuePaisa / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 font-sans">
              {customersWithDueCount} {lang === 'bn' ? 'জন গ্রাহকের নিকট বাকী' : 'customers with balance'}
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-amber-500" />
        </div>

        {/* Low Stock Warnings */}
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 font-sans">{t.lowStockAlerts}</span>
            <div
              className={`p-2 rounded-xl ${
                lowStockProducts.length > 0 ? 'bg-rose-50 text-rose-600 animate-pulse' : 'bg-slate-100 text-slate-500'
              }`}
            >
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div
              className={`text-2xl font-extrabold font-mono ${
                lowStockProducts.length > 0 ? 'text-rose-600' : 'text-slate-900'
              }`}
            >
              {lowStockProducts.length}
            </div>
            <div className="text-[11px] text-slate-500 mt-1 font-sans">
              {lowStockProducts.length > 0
                ? (lang === 'bn' ? 'পণ্য পুনরায় কিনতে হবে' : 'items below alert threshold')
                : (lang === 'bn' ? 'সব পণ্যে পর্যাপ্ত স্টক আছে' : 'All stock levels healthy')}
            </div>
          </div>
          <div
            className={`absolute bottom-0 left-0 right-0 h-1 ${
              lowStockProducts.length > 0 ? 'bg-rose-500' : 'bg-slate-300'
            }`}
          />
        </div>
      </div>

      {/* Quick Action Navigation Grid */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4 font-mono">
          {t.quickActions}
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <button
            onClick={() => onNavigateTab('pos')}
            className="flex items-center gap-3 p-3.5 rounded-xl border border-sky-100 bg-sky-50/50 hover:bg-sky-100 hover:border-sky-300 transition-all text-left group"
          >
            <div className="p-2.5 bg-sky-600 text-white rounded-xl shadow-sm group-hover:scale-105 transition-transform">
              <ShoppingCart className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900">{t.newSale}</div>
              <div className="text-[10px] text-slate-500">{lang === 'bn' ? 'কাউন্টার বিক্রি' : 'Point of Sale'}</div>
            </div>
          </button>

          <button
            onClick={() => onNavigateTab('suppliers')}
            className="flex items-center gap-3 p-3.5 rounded-xl border border-emerald-100 bg-emerald-50/50 hover:bg-emerald-100 hover:border-emerald-300 transition-all text-left group"
          >
            <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow-sm group-hover:scale-105 transition-transform">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900">{t.addStock}</div>
              <div className="text-[10px] text-slate-500">{lang === 'bn' ? 'মহাজন থেকে কেনা' : 'Purchase from vendor'}</div>
            </div>
          </button>

          <button
            onClick={() => onNavigateTab('customers')}
            className="flex items-center gap-3 p-3.5 rounded-xl border border-amber-100 bg-amber-50/50 hover:bg-amber-100 hover:border-amber-300 transition-all text-left group"
          >
            <div className="p-2.5 bg-amber-600 text-white rounded-xl shadow-sm group-hover:scale-105 transition-transform">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900">{t.addCustomer}</div>
              <div className="text-[10px] text-slate-500">{lang === 'bn' ? 'বাকীর হিসাব খাতা' : 'Manage balances'}</div>
            </div>
          </button>

          <button
            onClick={() => onNavigateTab('reports')}
            className="flex items-center gap-3 p-3.5 rounded-xl border border-indigo-100 bg-indigo-50/50 hover:bg-indigo-100 hover:border-indigo-300 transition-all text-left group"
          >
            <div className="p-2.5 bg-indigo-600 text-white rounded-xl shadow-sm group-hover:scale-105 transition-transform">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-bold text-slate-900">{t.viewReports}</div>
              <div className="text-[10px] text-slate-500">{lang === 'bn' ? 'লাভ ও বিক্রি হিসাব' : 'Sales & profit stats'}</div>
            </div>
          </button>
        </div>
      </div>

      {/* Low Stock Warning List + Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Low Stock Items Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-500" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-mono">
                {lang === 'bn' ? 'স্টক সংকট সতর্কতা' : 'Low Stock Items Warning'}
              </h3>
            </div>
            <button
              onClick={() => onNavigateTab('products')}
              className="text-[11px] text-sky-600 hover:text-sky-700 font-bold flex items-center gap-1"
            >
              <span>{lang === 'bn' ? 'সব পণ্য দেখুন' : 'View all'}</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {lowStockProducts.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-slate-50 rounded-xl border border-slate-100 text-slate-400 text-xs">
              <Package className="w-8 h-8 text-emerald-500 mb-2" />
              <span className="font-semibold text-slate-700">
                {lang === 'bn' ? 'কোনো পণ্য স্টক সংকটে নেই!' : 'Inventory is well-stocked!'}
              </span>
              <span className="text-[11px] text-slate-400 mt-0.5">
                {lang === 'bn' ? 'সব আইটেম নূন্যতম স্টকের উপরে রয়েছে।' : 'All items are above their alert threshold.'}
              </span>
            </div>
          ) : (
            <div className="space-y-2.5 overflow-y-auto max-h-64 pr-1">
              {lowStockProducts.slice(0, 6).map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-2.5 bg-rose-50/40 border border-rose-100 rounded-xl hover:bg-rose-50 transition-colors"
                >
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-slate-900 truncate">
                      {lang === 'bn' && item.name_bn ? item.name_bn : item.name}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      Barcode: {item.barcode || 'N/A'} · Alert at: {item.low_stock_threshold ?? 5}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono font-bold text-rose-600 px-2 py-0.5 bg-rose-100 border border-rose-200 rounded-lg">
                      {item.stock_qty} {item.unit || 'pcs'} left
                    </span>
                    <button
                      onClick={() => onNavigateTab('suppliers')}
                      className="text-[10px] bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-semibold px-2 py-1 rounded-lg transition-colors"
                    >
                      {lang === 'bn' ? 'মাল তুলুন' : 'Restock'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Sales List Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-sky-600" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider font-mono">
                {t.recentTransactions}
              </h3>
            </div>
            <button
              onClick={() => onNavigateTab('sales')}
              className="text-[11px] text-sky-600 hover:text-sky-700 font-bold flex items-center gap-1"
            >
              <span>{lang === 'bn' ? 'সব মেমো দেখুন' : 'View all'}</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          {recentSales.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-slate-50 rounded-xl border border-slate-100 text-slate-400 text-xs">
              <Receipt className="w-8 h-8 text-slate-300 mb-2" />
              <span className="font-semibold text-slate-600">
                {lang === 'bn' ? 'আজকের কোনো লেনদেন পাওয়া যায়নি।' : 'No sales recorded yet today.'}
              </span>
            </div>
          ) : (
            <div className="space-y-2.5 overflow-y-auto max-h-64 pr-1">
              {recentSales.map((sale) => (
                <div
                  key={sale.id}
                  className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-100 rounded-xl hover:bg-slate-100/80 transition-colors"
                >
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-slate-900 font-mono">{sale.invoice_no}</div>
                    <div className="text-[10px] text-slate-500">
                      {sale.customer_name || (lang === 'bn' ? 'খুচরা গ্রাহক' : 'Walking Customer')} ·{' '}
                      {new Date(sale.created_at).toLocaleTimeString(lang === 'bn' ? 'bn-BD' : 'en-US', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-bold font-mono text-slate-900">
                      ৳ {((sale.final_amount_paisa || 0) / 100).toFixed(2)}
                    </div>
                    <span
                      className={`text-[9px] font-mono px-1.5 py-0.2 rounded-full uppercase font-bold ${
                        sale.payment_method === 'cash'
                          ? 'bg-emerald-100 text-emerald-800'
                          : sale.payment_method === 'due'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-sky-100 text-sky-800'
                      }`}
                    >
                      {sale.payment_method}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
