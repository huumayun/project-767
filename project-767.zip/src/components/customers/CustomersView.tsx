import React, { useState, useEffect } from 'react';
import { Customer, CustomerDueSummary, UserSession } from '../../types/ipc';
import {
  Users,
  Search,
  Plus,
  Edit2,
  Trash2,
  DollarSign,
  FileText,
  AlertCircle,
  RefreshCw,
  Phone,
  MapPin,
  CheckCircle2,
  UserPlus,
  MessageSquare,
  Share2,
} from 'lucide-react';
import { CustomerFormModal } from './CustomerFormModal';
import { DueCollectionModal } from './DueCollectionModal';
import { CustomerLedgerModal } from './CustomerLedgerModal';
import { ConfirmModal } from '../common/ConfirmModal';
import { useToast } from '../../context/ToastContext';

interface CustomersViewProps {
  currentSession: UserSession | null;
}

export const CustomersView: React.FC<CustomersViewProps> = ({ currentSession }) => {
  const toast = useToast();
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [dueSummary, setDueSummary] = useState<CustomerDueSummary | null>(null);
  const [search, setSearch] = useState('');
  const [dueOnlyFilter, setDueOnlyFilter] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Modals
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [collectTargetCustomer, setCollectTargetCustomer] = useState<Customer | null>(null);
  const [showCollectModal, setShowCollectModal] = useState(false);
  const [ledgerTargetCustomer, setLedgerTargetCustomer] = useState<Customer | null>(null);
  const [showLedgerModal, setShowLedgerModal] = useState(false);

  // Delete Confirm Modal State
  const [deleteTargetCustomer, setDeleteTargetCustomer] = useState<Customer | null>(null);

  const isOwner = currentSession?.role === 'owner';

  const fetchData = async () => {
    if (!window.api) return;
    setLoading(true);
    setError(null);
    try {
      const [list, summary] = await Promise.all([
        window.api.customers.list(),
        window.api.customers.getDueSummary(),
      ]);
      setCustomers(list);
      setDueSummary(summary);
    } catch (err: any) {
      setError(err.message || 'Failed to load customer directory.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleDeletePrompt = (customer: Customer) => {
    if (customer.due_paisa && customer.due_paisa > 0) {
      toast.error(
        `Cannot delete customer! Outstanding due balance of ৳ ${(customer.due_paisa / 100).toFixed(
          2
        )} must be cleared first.`
      );
      return;
    }
    setDeleteTargetCustomer(customer);
  };

  const confirmDelete = async () => {
    if (!deleteTargetCustomer || !window.api) return;
    try {
      await window.api.customers.delete(deleteTargetCustomer.id);
      toast.success(`Customer profile "${deleteTargetCustomer.name}" deleted.`);
      setDeleteTargetCustomer(null);
      fetchData();
    } catch (err: any) {
      toast.error(`Delete failed: ${err.message}`);
    }
  };

  // WhatsApp Reminder Handler
  const handleSendWhatsAppReminder = (cust: Customer) => {
    const dueAmount = ((cust.due_paisa || 0) / 100).toFixed(2);
    const message = `সম্মানিত ${cust.name}, আমাদের দোকানে আপনার মোট বকেয়া ৳${dueAmount} টাকা। অনুগ্রহ করে দ্রুত পরিশোধ করার অনুরোধ রইল। ধন্যবাদ।`;

    let cleanPhone = (cust.phone || '').replace(/[^0-9]/g, '');
    if (cleanPhone.startsWith('01')) {
      cleanPhone = '880' + cleanPhone.slice(1);
    } else if (cleanPhone.startsWith('1')) {
      cleanPhone = '880' + cleanPhone;
    }

    if (cleanPhone.length >= 10) {
      const waUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
      window.open(waUrl, '_blank');
      toast.success(`WhatsApp reminder generated for ${cust.name}`);
    } else {
      // If phone number is incomplete, copy message to clipboard
      navigator.clipboard.writeText(message);
      toast.info('No valid phone number for direct link. Reminder message copied to clipboard!');
    }
  };

  const filteredCustomers = customers.filter((c) => {
    if (dueOnlyFilter && (!c.due_paisa || c.due_paisa <= 0)) return false;
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      (c.phone && c.phone.includes(q)) ||
      (c.address && c.address.toLowerCase().includes(q))
    );
  });

  return (
    <div className="h-full flex-1 flex flex-col overflow-hidden min-h-0 space-y-2.5 text-slate-900 font-sans">
      {/* Top Header - Fixed */}
      <div className="flex-shrink-0 flex items-center justify-between flex-wrap gap-3 bg-white border border-slate-200 p-3 sm:p-3.5 rounded-2xl shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-sky-50 text-sky-600 rounded-xl border border-sky-200">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">Customer & Due (বাকী) Management</h2>
            <p className="text-xs text-slate-500">Live derived due ledger, partial payments, and collection receipts</p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => {
              setEditingCustomer(null);
              setShowFormModal(true);
            }}
            className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md transition-colors"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Customer</span>
          </button>

          <button
            onClick={fetchData}
            className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl border border-slate-300 transition-colors"
            title="Reload Directory"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Due Summary KPIs - Fixed */}
      {dueSummary && (
        <div className="flex-shrink-0 grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
          <div className="bg-white border border-slate-200 p-3 rounded-2xl shadow-sm flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-500 font-sans block">Total Active Customers</span>
              <span className="text-lg font-extrabold text-slate-900">{dueSummary.total_customers_count}</span>
            </div>
            <div className="p-2 bg-slate-50 text-slate-600 rounded-xl">
              <Users className="w-4 h-4" />
            </div>
          </div>

          <div className="bg-white border border-slate-200 p-3 rounded-2xl shadow-sm flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-500 font-sans block">Customers with Due Balance</span>
              <span className="text-lg font-extrabold text-amber-700">
                {dueSummary.customers_with_due_count}
              </span>
            </div>
            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>

          <div className="bg-white border border-slate-200 p-3 rounded-2xl shadow-sm flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-500 font-sans block">Total Outstanding Due</span>
              <span className="text-lg font-extrabold text-amber-700">
                ৳ {(dueSummary.total_due_paisa / 100).toFixed(2)}
              </span>
            </div>
            <div className="p-2 bg-amber-50 text-amber-600 rounded-xl">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
        </div>
      )}

      {/* Search & Due Filter Toolbar */}
      <div className="flex-shrink-0 flex items-center justify-between gap-3 bg-white border border-slate-200 p-2.5 rounded-2xl shadow-sm flex-wrap">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search customers by name, phone, or address..."
            className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-10 pr-4 py-1.5 text-xs focus:outline-none focus:border-sky-500 focus:bg-white"
          />
        </div>

        <button
          onClick={() => setDueOnlyFilter(!dueOnlyFilter)}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors border ${
            dueOnlyFilter
              ? 'bg-amber-600 text-white border-amber-700 shadow-sm'
              : 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
          }`}
        >
          <AlertCircle className="w-3.5 h-3.5" />
          <span>Show Due Only ({dueSummary?.customers_with_due_count || 0})</span>
        </button>
      </div>

      {error && (
        <div className="flex-shrink-0 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Customer Directory Table */}
      <div className="flex-1 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm flex flex-col min-h-0">
        <div className="flex-1 overflow-y-auto min-h-0">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="sticky top-0 bg-slate-100 text-slate-600 uppercase font-mono text-[10px] border-b border-slate-200 z-10">
              <tr>
                <th className="p-3.5">Customer Details</th>
                <th className="p-3.5">Contact Phone</th>
                <th className="p-3.5">Address</th>
                <th className="p-3.5 text-right">Lifetime Sales</th>
                <th className="p-3.5 text-right">Paid to Date</th>
                <th className="p-3.5 text-right">Balance Due</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11.5px]">
              {filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-12 text-center text-slate-400 font-sans text-xs">
                    No customer accounts found matching criteria.
                  </td>
                </tr>
              ) : (
                filteredCustomers.map((cust) => {
                  const due = cust.due_paisa || 0;
                  const hasDue = due > 0;

                  return (
                    <tr key={cust.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-3.5 font-sans">
                        <div className="font-bold text-slate-900 text-xs">{cust.name}</div>
                        {cust.notes && <div className="text-[10px] text-slate-400 mt-0.5">{cust.notes}</div>}
                      </td>
                      <td className="p-3.5 text-slate-600">
                        {cust.phone ? (
                          <span className="flex items-center gap-1">
                            <Phone className="w-3 h-3 text-slate-400" />
                            <span>{cust.phone}</span>
                          </span>
                        ) : (
                          '-'
                        )}
                      </td>
                      <td className="p-3.5 font-sans text-slate-600">{cust.address || '-'}</td>
                      <td className="p-3.5 text-right text-slate-600">
                        ৳ {((cust.total_sales_paisa || 0) / 100).toFixed(2)}
                      </td>
                      <td className="p-3.5 text-right text-emerald-700">
                        ৳ {((cust.total_paid_paisa || 0) / 100).toFixed(2)}
                      </td>
                      <td className="p-3.5 text-right">
                        <span
                          className={`font-extrabold text-sm ${
                            hasDue ? 'text-amber-700' : 'text-emerald-700'
                          }`}
                        >
                          ৳ {(due / 100).toFixed(2)}
                        </span>
                      </td>
                      <td className="p-3.5 text-center">
                        <div className="flex items-center justify-center gap-1.5 font-sans">
                          {hasDue && (
                            <>
                              <button
                                onClick={() => {
                                  setCollectTargetCustomer(cust);
                                  setShowCollectModal(true);
                                }}
                                className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-lg border border-amber-300 font-bold text-[11px] flex items-center gap-1 transition-colors"
                                title="Collect Due / Baki Payment"
                              >
                                <DollarSign className="w-3.5 h-3.5" />
                                <span>Collect</span>
                              </button>

                              <button
                                onClick={() => handleSendWhatsAppReminder(cust)}
                                className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg border border-emerald-300 font-bold text-[11px] flex items-center gap-1 transition-colors"
                                title="Send WhatsApp Due Reminder (বাংলা তাগাদা)"
                              >
                                <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                                <span>WhatsApp</span>
                              </button>
                            </>
                          )}

                          <button
                            onClick={() => {
                              setLedgerTargetCustomer(cust);
                              setShowLedgerModal(true);
                            }}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-300 transition-colors"
                            title="View Account Statement & Ledger"
                          >
                            <FileText className="w-3.5 h-3.5 text-sky-600" />
                          </button>

                          <button
                            onClick={() => {
                              setEditingCustomer(cust);
                              setShowFormModal(true);
                            }}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-300 transition-colors"
                            title="Edit Customer"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {isOwner && (
                            <button
                              onClick={() => handleDeletePrompt(cust)}
                              className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg border border-rose-200 transition-colors"
                              title="Delete Customer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {showFormModal && (
        <CustomerFormModal
          isOpen={showFormModal}
          onClose={() => setShowFormModal(false)}
          customer={editingCustomer}
          onSuccess={() => {
            fetchData();
            setShowFormModal(false);
          }}
        />
      )}

      {/* Collect Due Modal */}
      {showCollectModal && collectTargetCustomer && (
        <DueCollectionModal
          isOpen={showCollectModal}
          onClose={() => {
            setShowCollectModal(false);
            setCollectTargetCustomer(null);
          }}
          customer={collectTargetCustomer}
          onSuccess={() => {
            fetchData();
            setShowCollectModal(false);
            setCollectTargetCustomer(null);
          }}
        />
      )}

      {/* Account Statement / Ledger Modal */}
      {showLedgerModal && ledgerTargetCustomer && (
        <CustomerLedgerModal
          isOpen={showLedgerModal}
          onClose={() => {
            setShowLedgerModal(false);
            setLedgerTargetCustomer(null);
          }}
          customer={ledgerTargetCustomer}
        />
      )}

      {/* Custom Confirmation Modal */}
      <ConfirmModal
        isOpen={Boolean(deleteTargetCustomer)}
        title="Delete Customer Account"
        message={`Are you sure you want to permanently delete customer profile "${deleteTargetCustomer?.name}"?`}
        isDanger
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTargetCustomer(null)}
      />
    </div>
  );
};
