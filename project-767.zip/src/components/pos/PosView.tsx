import React, { useState, useEffect, useRef } from 'react';
import {
  Product,
  Category,
  CartItem,
  UserSession,
  Customer,
  PaymentItem,
  SaleRecord,
} from '../../types/ipc';
import {
  Search,
  Barcode,
  Trash2,
  Plus,
  Minus,
  PauseCircle,
  RotateCcw,
  CheckCircle,
  AlertTriangle,
  UserPlus,
  ShoppingBag,
  CreditCard,
  Layers,
  Sparkles,
  Printer,
  X,
  Smartphone,
  Tag,
  FileText,
} from 'lucide-react';
import { InvoiceModal } from './InvoiceModal';
import { HeldSalesModal } from './HeldSalesModal';
import { CustomerFormModal } from '../customers/CustomerFormModal';
import { ReceiptPreviewModal } from './ReceiptPreviewModal';
import { ConfirmModal } from '../common/ConfirmModal';
import { ProductFormModal } from '../products/ProductFormModal';
import { ReturnRefundModal } from './ReturnRefundModal';
import { useToast } from '../../context/ToastContext';
import { audio } from '../../utils/audio';

interface PosViewProps {
  products: Product[];
  currentSession: UserSession | null;
  onRefreshProducts: () => void;
}

export const PosView: React.FC<PosViewProps> = ({
  products,
  currentSession,
  onRefreshProducts,
}) => {
  const toast = useToast();

  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [showAddCustomerModal, setShowAddCustomerModal] = useState(false);

  // Scan Feedback visual state ('success' | 'error' | null)
  const [scanStatus, setScanStatus] = useState<'success' | 'error' | null>(null);
  const [unrecognizedBarcode, setUnrecognizedBarcode] = useState<string | null>(null);
  const [showAddProductModal, setShowAddProductModal] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);

  // Scanned Invoice Recognition
  const [scannedInvoiceSale, setScannedInvoiceSale] = useState<SaleRecord | null>(null);
  const [showInvoiceActionModal, setShowInvoiceActionModal] = useState(false);
  const [showReturnModal, setShowReturnModal] = useState(false);

  // Payments State
  const [cashAmount, setCashAmount] = useState<string>('');
  const [bkashAmount, setBkashAmount] = useState<string>('');
  const [nagadAmount, setNagadAmount] = useState<string>('');
  const [cardAmount, setCardAmount] = useState<string>('');
  const [discountTaka, setDiscountTaka] = useState<string>('0');
  const [invoiceLayout, setInvoiceLayout] = useState<'80mm' | 'a5'>('80mm');

  // Modals
  const [showPreviewModal, setShowPreviewModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [invoicePdfBase64, setInvoicePdfBase64] = useState('');
  const [lastInvoiceNo, setLastInvoiceNo] = useState('');
  const [showHeldModal, setShowHeldModal] = useState(false);

  // Confirm Modal state
  const [confirmModalConfig, setConfirmModalConfig] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const barcodeInputRef = useRef<HTMLInputElement>(null);

  // Fetch customers & categories
  const fetchData = async () => {
    if (!window.api) return;
    try {
      const [custList, catList] = await Promise.all([
        window.api.customers.list().catch(() => []),
        window.api.categories.list().catch(() => []),
      ]);
      setCustomers(custList);
      setCategories(catList);
    } catch (err) {
      console.error('Failed to load initial data:', err);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Global barcode scanner listener & shortcuts
  useEffect(() => {
    let scanBuffer = '';
    let lastKeyTime = Date.now();

    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      // Shortcuts
      if (e.key === 'F2') {
        e.preventDefault();
        barcodeInputRef.current?.focus();
        barcodeInputRef.current?.select();
        return;
      }
      if (e.key === 'F4') {
        e.preventDefault();
        handleQuickCash();
        return;
      }
      if (e.key === 'F8') {
        e.preventDefault();
        handleStartCheckout();
        return;
      }
      if (e.key === 'F9') {
        e.preventDefault();
        handleHoldCart();
        return;
      }
      if (e.key === 'Escape') {
        if (cart.length > 0) {
          e.preventDefault();
          handleClearCart();
        }
        return;
      }

      const target = e.target as HTMLElement;
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes(target.tagName)) {
        return;
      }

      const now = Date.now();
      if (e.key === 'Enter' && scanBuffer.length > 2) {
        handleBarcodeScanned(scanBuffer.trim());
        scanBuffer = '';
        return;
      }

      if (now - lastKeyTime > 150) {
        scanBuffer = '';
      }
      if (e.key.length === 1) {
        scanBuffer += e.key;
      }
      lastKeyTime = now;
    };

    window.addEventListener('keydown', handleGlobalKeyDown);
    return () => window.removeEventListener('keydown', handleGlobalKeyDown);
  }, [cart, products]);

  const triggerScanFlash = (status: 'success' | 'error') => {
    setScanStatus(status);
    setTimeout(() => setScanStatus(null), 500);
  };

  const handleBarcodeScanned = async (scannedCode: string) => {
    const trimmed = scannedCode.trim();
    if (!trimmed) return;

    // 1. Check if scanned code is an Invoice (starts with INV- or lookup returns a sale)
    if (trimmed.toUpperCase().startsWith('INV-')) {
      if (window.api) {
        try {
          const sale = await window.api.sales.getByInvoice(trimmed);
          if (sale) {
            audio.playScanSuccess();
            triggerScanFlash('success');
            setUnrecognizedBarcode(null);
            setScannedInvoiceSale(sale);
            setShowInvoiceActionModal(true);
            toast.success(`ইনভয়েস পাওয়া গেছে: #${sale.invoice_no}`);
            return;
          }
        } catch (err) {
          console.error('Invoice lookup error:', err);
        }
      }
    }

    // 2. Look for product by barcode
    const found = products.find(
      (p) => p.barcode?.toLowerCase() === trimmed.toLowerCase()
    );
    if (found) {
      audio.playScanSuccess();
      triggerScanFlash('success');
      setUnrecognizedBarcode(null);
      addToCart(found);
      toast.success(`Scanned: ${found.name}`);
    } else {
      // Check fallback if it is an invoice without INV- prefix
      if (window.api) {
        try {
          const sale = await window.api.sales.getByInvoice(trimmed);
          if (sale) {
            audio.playScanSuccess();
            triggerScanFlash('success');
            setUnrecognizedBarcode(null);
            setScannedInvoiceSale(sale);
            setShowInvoiceActionModal(true);
            toast.success(`ইনভয়েস পাওয়া গেছে: #${sale.invoice_no}`);
            return;
          }
        } catch {
          // not an invoice
        }
      }

      audio.playScanError();
      triggerScanFlash('error');
      setUnrecognizedBarcode(trimmed);
      toast.error(`বারকোড "${trimmed}" ইনভেন্টরিতে পাওয়া যায়নি।`);
    }
  };

  const addToCart = (product: Product) => {
    if (product.stock_qty <= 0) {
      audio.playScanError();
      triggerScanFlash('error');
      setError(`"${product.name}" is out of stock!`);
      toast.error(`"${product.name}" is out of stock!`);
      setTimeout(() => setError(null), 3000);
      return;
    }

    setCart((prev) => {
      const existing = prev.find((item) => item.product_id === product.id);
      if (existing) {
        if (existing.qty >= product.stock_qty) {
          audio.playScanError();
          triggerScanFlash('error');
          setError(`Cannot add more than available stock (${product.stock_qty}).`);
          toast.warning(`Maximum available stock reached (${product.stock_qty}).`);
          setTimeout(() => setError(null), 3000);
          return prev;
        }
        return prev.map((item) =>
          item.product_id === product.id
            ? { ...item, qty: item.qty + 1 }
            : item
        );
      } else {
        return [
          ...prev,
          {
            product_id: product.id,
            barcode: product.barcode,
            name: product.name,
            name_bn: product.name_bn,
            unit: product.unit,
            unit_price_paisa: product.sell_price_paisa,
            cost_price_paisa: product.cost_price_paisa,
            qty: 1,
            discount_paisa: 0,
            available_stock: product.stock_qty,
            is_serial_tracked: Boolean(product.is_serial_tracked),
          },
        ];
      }
    });
  };

  const updateCartQty = (productId: string, newQty: number) => {
    if (newQty <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.product_id === productId) {
          if (newQty > item.available_stock) {
            setError(`Max available stock is ${item.available_stock}`);
            toast.warning(`Max available stock is ${item.available_stock}`);
            setTimeout(() => setError(null), 3000);
            return item;
          }
          return { ...item, qty: newQty };
        }
        return item;
      })
    );
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product_id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
    setCashAmount('');
    setBkashAmount('');
    setNagadAmount('');
    setCardAmount('');
    setDiscountTaka('0');
    setError(null);
  };

  // Calculation (Integer Paisa)
  const subtotalPaisa = cart.reduce(
    (sum, item) => sum + item.unit_price_paisa * item.qty,
    0
  );
  const discountPaisa = Math.max(0, Math.round((parseFloat(discountTaka) || 0) * 100));
  const totalPaisa = Math.max(0, subtotalPaisa - discountPaisa);

  const cashPaisa = Math.round((parseFloat(cashAmount) || 0) * 100);
  const bkashPaisa = Math.round((parseFloat(bkashAmount) || 0) * 100);
  const nagadPaisa = Math.round((parseFloat(nagadAmount) || 0) * 100);
  const cardPaisa = Math.round((parseFloat(cardAmount) || 0) * 100);

  const totalPaidPaisa = cashPaisa + bkashPaisa + nagadPaisa + cardPaisa;
  const changePaisa = Math.max(0, totalPaidPaisa - totalPaisa);
  const duePaisa = Math.max(0, totalPaisa - totalPaidPaisa);

  // Quick Cash Fill (F4)
  const handleQuickCash = () => {
    if (totalPaisa <= 0) return;
    setCashAmount((totalPaisa / 100).toFixed(2));
    setBkashAmount('');
    setNagadAmount('');
    setCardAmount('');
    toast.info(`Exact cash ৳${(totalPaisa / 100).toFixed(2)} applied.`);
  };

  const handleHoldCart = async () => {
    if (cart.length === 0 || !window.api) return;
    try {
      const cust = customers.find((c) => c.id === selectedCustomerId);
      await window.api.sales.holdSale({
        cartData: cart,
        customerName: cust?.name,
      });
      toast.success('Cart parked / held successfully!');
      handleClearCart();
    } catch (err: any) {
      toast.error(`Failed to hold sale: ${err.message}`);
    }
  };

  const handleStartCheckout = () => {
    if (cart.length === 0) {
      toast.warning('Cart is empty. Scan or select products first.');
      return;
    }

    // Staff max discount validation (10%)
    if (currentSession?.role === 'staff') {
      const maxAllowedDiscount = Math.round(subtotalPaisa * 0.1);
      if (discountPaisa > maxAllowedDiscount) {
        toast.error(
          `Staff discount limit exceeded: ৳${(discountPaisa / 100).toFixed(
            2
          )} exceeds 10% maximum (৳${(maxAllowedDiscount / 100).toFixed(2)}). Ask Owner for approval.`
        );
        return;
      }
    }

    // If zero payment entered and no customer selected, ask confirmation
    if (totalPaidPaisa === 0 && !selectedCustomerId) {
      setConfirmModalConfig({
        isOpen: true,
        title: 'Walk-in Cash Customer Confirmation',
        message:
          'No payment amount entered and no customer account selected. Do you want to proceed as walk-in cash customer?',
        onConfirm: () => {
          setConfirmModalConfig((prev) => ({ ...prev, isOpen: false }));
          setShowPreviewModal(true);
        },
      });
      return;
    }

    // Open receipt preview modal
    setShowPreviewModal(true);
  };

  const executeFinalCheckout = async (shouldPrint: boolean) => {
    if (!window.api) return;
    setLoading(true);
    setError(null);

    const payments: PaymentItem[] = [];
    if (cashPaisa > 0) payments.push({ method: 'cash', amount_paisa: cashPaisa });
    if (bkashPaisa > 0) payments.push({ method: 'bkash', amount_paisa: bkashPaisa });
    if (nagadPaisa > 0) payments.push({ method: 'nagad', amount_paisa: nagadPaisa });
    if (cardPaisa > 0) payments.push({ method: 'card', amount_paisa: cardPaisa });

    if (payments.length === 0 && totalPaisa > 0) {
      payments.push({ method: 'cash', amount_paisa: 0 });
    }

    try {
      const res = await window.api.sales.create({
        customer_id: selectedCustomerId || null,
        subtotal_paisa: subtotalPaisa,
        discount_paisa: discountPaisa,
        total_paisa: totalPaisa,
        items: cart.map((item) => ({
          product_id: item.product_id,
          qty: item.qty,
          unit_price_paisa: item.unit_price_paisa,
          discount_paisa: item.discount_paisa,
        })),
        payments,
        total_paid_paisa: totalPaidPaisa,
        change_paisa: changePaisa,
        layout: invoiceLayout,
      });

      if (res.success) {
        toast.success(`Sale completed successfully! Invoice #${res.invoice_no}`);
        setLastInvoiceNo(res.invoice_no);
        setInvoicePdfBase64(res.pdfBase64 || '');
        setShowPreviewModal(false);

        if (shouldPrint) {
          setShowInvoiceModal(true);
        }

        handleClearCart();
        onRefreshProducts();
      }
    } catch (err: any) {
      toast.error(err.message || 'Checkout failed.');
      setError(err.message || 'Checkout failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleSearchKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const query = searchQuery.trim();
      if (!query) return;

      // Check if query matches barcode exactly
      const barcodeMatch = products.find(
        (p) => p.barcode?.toLowerCase() === query.toLowerCase()
      );
      if (barcodeMatch) {
        handleBarcodeScanned(query);
        setSearchQuery('');
        return;
      }

      // Check if there are name matches
      const matches = products.filter(
        (p) =>
          p.name.toLowerCase().includes(query.toLowerCase()) ||
          (p.name_bn && p.name_bn.toLowerCase().includes(query.toLowerCase())) ||
          (p.barcode && p.barcode.toLowerCase().includes(query.toLowerCase()))
      );

      if (matches.length === 1) {
        addToCart(matches[0]);
        audio.playScanSuccess();
        toast.success(`যোগ হয়েছে: ${matches[0].name}`);
        setSearchQuery('');
      } else if (matches.length === 0) {
        handleBarcodeScanned(query);
        setSearchQuery('');
      }
    }
  };

  const filteredProducts = products.filter((p) => {
    if (!searchQuery.trim()) return false;
    const q = searchQuery.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      (p.name_bn && p.name_bn.toLowerCase().includes(q)) ||
      (p.barcode && p.barcode.toLowerCase().includes(q)) ||
      (p.brand && p.brand.toLowerCase().includes(q))
    );
  });

  const selectedCustomer = customers.find((c) => c.id === selectedCustomerId);

  let paymentSummaryStr = 'Cash';
  if (bkashPaisa > 0) paymentSummaryStr = 'bKash';
  else if (nagadPaisa > 0) paymentSummaryStr = 'Nagad';
  else if (cardPaisa > 0) paymentSummaryStr = 'Card';
  else if (totalPaidPaisa === 0 && duePaisa > 0) paymentSummaryStr = 'Full Due';

  return (
    <div className="h-full flex-1 flex flex-col overflow-hidden min-h-0 text-slate-900 font-sans select-none">
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-3 sm:gap-4 overflow-hidden min-h-0">
        {/* ========================================================================= */}
        {/* LEFT COLUMN: BARCODE SCANNER, SEARCH & ACTIVE BILL / CART ITEMS TABLE      */}
        {/* ========================================================================= */}
        <div className="lg:col-span-7 xl:col-span-7 2xl:col-span-8 flex flex-col h-full overflow-hidden min-h-0 space-y-2.5">
          
          {/* Top Search & Barcode Scanner Bar */}
          <div
            className={`flex-shrink-0 bg-white border p-2.5 sm:p-3 rounded-2xl shadow-sm flex items-center gap-2 sm:gap-3 flex-wrap sm:flex-nowrap transition-all duration-300 ${
              scanStatus === 'success'
                ? 'border-emerald-500 ring-2 ring-emerald-400/50 bg-emerald-50/20'
                : scanStatus === 'error'
                ? 'border-rose-500 ring-2 ring-rose-400/50 bg-rose-50/20'
                : 'border-slate-200'
            }`}
          >
            <div className="relative flex-1 min-w-[200px]">
              <Barcode className="w-4 h-4 text-sky-600 absolute left-3.5 top-2.5 pointer-events-none" />
              <input
                ref={barcodeInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleSearchKeyDown}
                placeholder="বারকোড স্ক্যান করুন বা পার্টসের নাম লিখুন (Press F2 / Enter)..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-900 focus:outline-none focus:border-sky-500 focus:bg-white font-mono font-semibold placeholder:font-sans placeholder:text-slate-400"
              />

              {/* Instant Search Results Dropdown */}
              {searchQuery.trim().length > 0 && filteredProducts.length > 0 && (
                <div className="absolute left-0 right-0 top-full mt-1.5 bg-white border border-slate-300 rounded-2xl shadow-2xl z-30 max-h-64 overflow-y-auto divide-y divide-slate-100 animate-fade-in">
                  <div className="px-3 py-1.5 bg-slate-50 text-[11px] font-bold text-slate-500 font-mono">
                    পণ্যসমূহ ({filteredProducts.length} টি পাওয়া গেছে - ক্লিক করে কার্টে যোগ করুন):
                  </div>
                  {filteredProducts.slice(0, 8).map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => {
                        addToCart(p);
                        setSearchQuery('');
                        barcodeInputRef.current?.focus();
                      }}
                      className="w-full p-3 text-left hover:bg-sky-50 flex items-center justify-between transition-colors group"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="font-bold text-slate-900 text-xs group-hover:text-sky-700">
                          {p.name_bn ? `${p.name_bn} (${p.name})` : p.name}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono flex items-center gap-2 mt-0.5">
                          <span>{p.barcode ? `BC: ${p.barcode}` : 'No Barcode'}</span>
                          {p.brand && <span>· {p.brand}</span>}
                        </div>
                      </div>
                      <div className="text-right flex-shrink-0 ml-3">
                        <div className="text-xs font-mono font-extrabold text-sky-700">
                          ৳ {(p.sell_price_paisa / 100).toFixed(2)}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          স্টক: {p.stock_qty} {p.unit || 'pcs'}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Add Product Button */}
            <button
              onClick={() => {
                setUnrecognizedBarcode(null);
                setShowAddProductModal(true);
              }}
              className="px-3.5 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-sky-600/20 transition-all flex-shrink-0"
              title="Add New Mechanical Product / Part"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">নতুন প্রোডাক্ট</span>
            </button>

            {/* Recall Held Carts */}
            <button
              onClick={() => setShowHeldModal(true)}
              className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-300 flex-shrink-0"
              title="Recall Parked / Held Carts (F9)"
            >
              <Layers className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden sm:inline">Held Carts</span>
            </button>
          </div>

          {/* Unrecognized Barcode Quick-Add Banner */}
          {unrecognizedBarcode && (
            <div className="flex-shrink-0 p-3 bg-amber-50 border border-amber-300 rounded-2xl text-amber-900 text-xs flex items-center justify-between gap-3 shadow-sm animate-fade-in">
              <div className="flex items-center gap-2">
                <Barcode className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <span>
                  বারকোড <strong className="font-mono bg-amber-200/60 px-1.5 py-0.5 rounded">"{unrecognizedBarcode}"</strong> ইনভেন্টরিতে নেই।
                </span>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={() => setShowAddProductModal(true)}
                  className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>এখনই প্রোডাক্ট যোগ করুন</span>
                </button>
                <button
                  onClick={() => setUnrecognizedBarcode(null)}
                  className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
                  title="Dismiss"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {error && (
            <div className="flex-shrink-0 p-2.5 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Active Bill / Cart Table */}
          <div className="flex-1 bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden flex flex-col min-h-0">
            <div className="flex-shrink-0 px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-sky-600" />
                <span className="font-bold text-xs text-slate-800 uppercase tracking-wider">
                  বিল আইটেম তালিকা (Active Bill Lines)
                </span>
              </div>
              <span className="text-xs font-mono font-bold text-slate-600 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                {cart.length} টি আইটেম
              </span>
            </div>

            <div className="flex-1 overflow-y-auto min-h-0">
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 text-xs py-12 px-4 text-center">
                  <div className="p-4 bg-sky-50 text-sky-600 rounded-full mb-3 border border-sky-100 shadow-inner">
                    <Barcode className="w-10 h-10" />
                  </div>
                  <h3 className="font-bold text-slate-800 text-sm mb-1">কার্ট বর্তমানে খালি</h3>
                  <p className="text-xs text-slate-500 max-w-sm mb-4">
                    বারকোড স্ক্যানার দিয়ে পার্টসের বারকোড স্ক্যান করুন অথবা উপরের সার্চ বক্সে পার্টসের নাম লিখুন।
                  </p>
                  <button
                    onClick={() => {
                      setUnrecognizedBarcode(null);
                      setShowAddProductModal(true);
                    }}
                    className="px-4 py-2 bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-xl text-xs font-bold border border-sky-200 flex items-center gap-1.5 transition-colors shadow-sm"
                  >
                    <Plus className="w-4 h-4" />
                    <span>ম্যানুয়ালি নতুন প্রোডাক্ট যোগ করুন</span>
                  </button>
                </div>
              ) : (
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-100 text-slate-600 uppercase font-mono text-[10px] tracking-wider border-b border-slate-200 sticky top-0 z-10">
                    <tr>
                      <th className="p-3 text-center w-10">#</th>
                      <th className="p-3">পণ্যের বিবরণ (Product Details)</th>
                      <th className="p-3 text-right">একক মূল্য</th>
                      <th className="p-3 text-center w-36">পরিমাণ (Qty)</th>
                      <th className="p-3 text-right w-28">মোট টাকা</th>
                      <th className="p-3 text-center w-12">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {cart.map((item, idx) => (
                      <tr key={item.product_id} className="hover:bg-sky-50/40 transition-colors">
                        <td className="p-3 text-center font-mono text-slate-400 font-semibold">
                          {idx + 1}
                        </td>
                        <td className="p-3">
                          <div className="font-bold text-slate-900 text-xs">
                            {item.name_bn ? `${item.name_bn} (${item.name})` : item.name}
                          </div>
                          <div className="text-[10px] text-slate-500 font-mono flex items-center gap-2 mt-0.5">
                            <span>{item.barcode ? `BC: ${item.barcode}` : 'No Barcode'}</span>
                            <span className="text-slate-400">· মজুদ: {item.available_stock} {item.unit || 'pcs'}</span>
                          </div>
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-slate-800">
                          ৳ {(item.unit_price_paisa / 100).toFixed(2)}
                        </td>
                        <td className="p-3 text-center">
                          <div className="inline-flex items-center border border-slate-300 rounded-xl bg-slate-50 overflow-hidden shadow-sm">
                            <button
                              onClick={() => updateCartQty(item.product_id, item.qty - 1)}
                              className="px-2 py-1 hover:bg-slate-200 text-slate-700 font-bold transition-colors"
                              title="Decrease Qty"
                            >
                              <Minus className="w-3.5 h-3.5" />
                            </button>
                            <span className="px-3 py-1 font-mono font-bold text-slate-900 text-xs min-w-[28px] text-center bg-white border-x border-slate-200">
                              {item.qty}
                            </span>
                            <button
                              onClick={() => updateCartQty(item.product_id, item.qty + 1)}
                              className="px-2 py-1 hover:bg-slate-200 text-slate-700 font-bold transition-colors"
                              title="Increase Qty"
                            >
                              <Plus className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                        <td className="p-3 text-right font-mono font-extrabold text-sky-800 text-xs">
                          ৳ {((item.unit_price_paisa * item.qty) / 100).toFixed(2)}
                        </td>
                        <td className="p-3 text-center">
                          <button
                            onClick={() => removeFromCart(item.product_id)}
                            className="text-slate-400 hover:text-rose-600 hover:bg-rose-50 p-1.5 rounded-lg transition-colors"
                            title="Remove from Cart"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>

        {/* ========================================================================= */}
        {/* RIGHT COLUMN: CUSTOMER, PRICING, PAYMENT CALCULATION & CHECKOUT           */}
        {/* ========================================================================= */}
        <div className="lg:col-span-5 xl:col-span-5 2xl:col-span-4 bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col h-full overflow-hidden min-h-0 justify-between space-y-3">
          
          {/* Customer Selector & Quick Actions */}
          <div className="flex-shrink-0 border-b border-slate-200 pb-3 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 font-sans flex items-center gap-1.5">
                <span>গ্রাহক নির্বাচন (Customer)</span>
              </label>
              <div className="flex items-center gap-1">
                <button
                  onClick={handleHoldCart}
                  disabled={cart.length === 0}
                  className="px-2 py-1 bg-slate-100 hover:bg-amber-100 hover:text-amber-800 text-slate-600 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-colors disabled:opacity-40"
                  title="Park / Hold Cart (F9)"
                >
                  <PauseCircle className="w-3.5 h-3.5" />
                  <span>Hold</span>
                </button>
                <button
                  onClick={handleClearCart}
                  disabled={cart.length === 0}
                  className="px-2 py-1 bg-slate-100 hover:bg-rose-100 hover:text-rose-800 text-slate-600 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-colors disabled:opacity-40"
                  title="Clear Cart (Esc)"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Clear</span>
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={selectedCustomerId}
                onChange={(e) => setSelectedCustomerId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-sky-500 font-sans font-semibold"
              >
                <option value="">Walk-in Customer (খুচরা ক্রেতা)</option>
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} {c.phone ? `(${c.phone})` : ''} {(c.due_paisa || 0) > 0 ? `[Due: ৳${((c.due_paisa || 0) / 100).toFixed(2)}]` : ''}
                  </option>
                ))}
              </select>
              <button
                onClick={() => setShowAddCustomerModal(true)}
                className="p-2 bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-xl border border-sky-200 transition-colors flex-shrink-0"
                title="Add New Customer"
              >
                <UserPlus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Pricing & Payable Summary (Large Highlight) */}
          <div className="flex-shrink-0 bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-2 text-xs">
            <div className="flex justify-between text-slate-600 text-xs">
              <span>মোট পণ্যের দাম (Subtotal):</span>
              <span className="font-mono font-bold text-slate-800">৳ {(subtotalPaisa / 100).toFixed(2)}</span>
            </div>

            <div className="flex items-center justify-between gap-2">
              <span className="text-slate-700 font-semibold">ছাড় / ডিসকাউন্ট (৳):</span>
              <input
                type="number"
                min="0"
                value={discountTaka}
                onChange={(e) => setDiscountTaka(e.target.value)}
                placeholder="0"
                className="w-28 bg-white border border-slate-300 rounded-xl px-2.5 py-1 text-xs text-right font-mono font-bold text-amber-700 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex justify-between items-center bg-sky-600 text-white p-3 rounded-xl shadow-md mt-1">
              <div>
                <span className="text-[11px] uppercase tracking-wider block font-semibold text-sky-100">সর্বমোট প্রদেয়</span>
                <span className="text-xs font-bold">Payable Total</span>
              </div>
              <span className="text-xl font-extrabold font-mono tracking-tight">
                ৳ {(totalPaisa / 100).toFixed(2)}
              </span>
            </div>
          </div>

          {/* Split Payment Methods */}
          <div className="flex-1 overflow-y-auto space-y-2 text-xs min-h-0">
            <label className="text-[11px] font-bold uppercase tracking-wider text-slate-500 font-mono block">
              পরিশোধের মাধ্যম (Payment Breakdown)
            </label>

            <div className="grid grid-cols-2 gap-2 font-mono">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-700 font-sans font-semibold">ক্যাশ (Cash ৳)</span>
                  <button
                    type="button"
                    onClick={handleQuickCash}
                    className="text-[10px] font-sans text-sky-600 hover:underline font-bold"
                  >
                    Exact (F4)
                  </button>
                </div>
                <input
                  type="number"
                  min="0"
                  value={cashAmount}
                  onChange={(e) => setCashAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs text-slate-900 font-bold focus:outline-none focus:border-sky-500 focus:bg-white"
                />
              </div>

              <div>
                <span className="text-pink-700 font-sans font-semibold block mb-1">বিকাশ (bKash ৳)</span>
                <input
                  type="number"
                  min="0"
                  value={bkashAmount}
                  onChange={(e) => setBkashAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs text-slate-900 font-bold focus:outline-none focus:border-pink-500 focus:bg-white"
                />
              </div>

              <div>
                <span className="text-orange-700 font-sans font-semibold block mb-1">নগদ (Nagad ৳)</span>
                <input
                  type="number"
                  min="0"
                  value={nagadAmount}
                  onChange={(e) => setNagadAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs text-slate-900 font-bold focus:outline-none focus:border-orange-500 focus:bg-white"
                />
              </div>

              <div>
                <span className="text-sky-700 font-sans font-semibold block mb-1">কার্ড / ব্যাংক (৳)</span>
                <input
                  type="number"
                  min="0"
                  value={cardAmount}
                  onChange={(e) => setCardAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs text-slate-900 font-bold focus:outline-none focus:border-sky-500 focus:bg-white"
                />
              </div>
            </div>

            {/* Payment Balance Info (Paid, Change, Due) */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-mono">
              <div className="text-slate-600">
                মোট জমা: <span className="font-bold text-slate-900">৳ {(totalPaidPaisa / 100).toFixed(2)}</span>
              </div>
              {changePaisa > 0 && (
                <div className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200 font-bold">
                  ফেরত: ৳ {(changePaisa / 100).toFixed(2)}
                </div>
              )}
              {duePaisa > 0 && (
                <div className="text-rose-700 bg-rose-50 px-2 py-0.5 rounded-lg border border-rose-200 font-bold">
                  বকেয়া: ৳ {(duePaisa / 100).toFixed(2)}
                </div>
              )}
            </div>
          </div>

          {/* Checkout & Print Format Buttons */}
          <div className="flex-shrink-0 space-y-2 pt-2 border-t border-slate-200">
            <div className="flex items-center gap-2">
              <select
                value={invoiceLayout}
                onChange={(e) => setInvoiceLayout(e.target.value as any)}
                className="bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-700 font-semibold focus:outline-none focus:border-sky-500"
              >
                <option value="80mm">80mm Thermal POS</option>
                <option value="a5">A5 Sheet</option>
              </select>

              <button
                type="button"
                onClick={handleStartCheckout}
                disabled={cart.length === 0 || loading}
                className="flex-1 py-2.5 bg-gradient-to-r from-sky-600 to-sky-500 hover:from-sky-500 hover:to-sky-400 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-lg shadow-sky-600/25 flex items-center justify-center gap-2 transition-all disabled:opacity-50 active:scale-[0.98]"
              >
                <CheckCircle className="w-4 h-4" />
                <span>বিল তৈরি ও প্রিন্ট প্রিভিউ (F8)</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* POS Bottom Keyboard Shortcut Helper Bar */}
      <div className="flex-shrink-0 bg-slate-900 text-slate-300 px-4 py-1.5 rounded-xl border border-slate-800 text-[11px] font-mono flex items-center justify-between flex-wrap gap-2 mt-2 shadow-sm">
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-slate-500 font-sans font-bold">Shortcuts:</span>
          <span className="flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
            <kbd className="text-sky-400 font-bold">F2</kbd> Focus Scan/Search
          </span>
          <span className="flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
            <kbd className="text-emerald-400 font-bold">F4</kbd> Exact Cash
          </span>
          <span className="flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
            <kbd className="text-amber-400 font-bold">F8</kbd> Checkout & Preview
          </span>
          <span className="flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
            <kbd className="text-indigo-400 font-bold">F9</kbd> Hold Cart
          </span>
          <span className="flex items-center gap-1 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
            <kbd className="text-rose-400 font-bold">Esc</kbd> Clear Cart
          </span>
        </div>
        <div className="text-[10px] text-slate-500">
          Audio Feedback: Active 🔊
        </div>
      </div>

      {/* Receipt Preview & Confirmation Modal */}
      <ReceiptPreviewModal
        isOpen={showPreviewModal}
        onClose={() => setShowPreviewModal(false)}
        onConfirmSale={executeFinalCheckout}
        cart={cart}
        customer={selectedCustomer}
        subtotalPaisa={subtotalPaisa}
        discountPaisa={discountPaisa}
        totalPaisa={totalPaisa}
        paidPaisa={totalPaidPaisa}
        changePaisa={changePaisa}
        duePaisa={duePaisa}
        paymentMethodSummary={paymentSummaryStr}
        invoiceLayout={invoiceLayout}
        loading={loading}
      />

      {/* Final Printed Invoice Modal */}
      <InvoiceModal
        isOpen={showInvoiceModal}
        onClose={() => setShowInvoiceModal(false)}
        invoiceNo={lastInvoiceNo}
        pdfBase64={invoicePdfBase64}
        layout={invoiceLayout}
      />

      {/* Held Sales Modal */}
      <HeldSalesModal
        isOpen={showHeldModal}
        onClose={() => setShowHeldModal(false)}
        onRestoreCart={(restoredCart) => {
          setCart(restoredCart);
          setShowHeldModal(false);
        }}
      />

      {/* Quick Add Customer Modal */}
      {showAddCustomerModal && (
        <CustomerFormModal
          isOpen={showAddCustomerModal}
          onClose={() => setShowAddCustomerModal(false)}
          onSuccess={(newCust) => {
            fetchData();
            setSelectedCustomerId(newCust.id);
            setShowAddCustomerModal(false);
          }}
        />
      )}

      {/* Quick Add Product from Scanned Barcode Modal */}
      {showAddProductModal && (
        <ProductFormModal
          isOpen={showAddProductModal}
          onClose={() => setShowAddProductModal(false)}
          initialBarcode={unrecognizedBarcode || ''}
          categories={categories}
          onSuccess={async () => {
            setShowAddProductModal(false);
            onRefreshProducts();
            if (unrecognizedBarcode) {
              const code = unrecognizedBarcode;
              setUnrecognizedBarcode(null);
              setTimeout(async () => {
                try {
                  if (window.api) {
                    const fresh = await window.api.products.getByBarcode(code);
                    if (fresh) {
                      addToCart(fresh);
                      toast.success(`"${fresh.name}" যোগ করা হয়েছে এবং কার্টে যুক্ত হয়েছে!`);
                    }
                  }
                } catch (err) {
                  console.error(err);
                }
              }, 400);
            }
          }}
          onAddCategory={async (name: string) => {
            if (!window.api) return null;
            try {
              const cat = await window.api.categories.create(name);
              setCategories((prev) => [...prev, cat]);
              return cat;
            } catch (err: any) {
              toast.error(err.message || 'Failed to add category');
              return null;
            }
          }}
        />
      )}

      {/* Custom Confirmation Modal */}
      <ConfirmModal
        isOpen={confirmModalConfig.isOpen}
        title={confirmModalConfig.title}
        message={confirmModalConfig.message}
        onConfirm={confirmModalConfig.onConfirm}
        onCancel={() => setConfirmModalConfig((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* Scanned Invoice Quick Action Modal */}
      {showInvoiceActionModal && scannedInvoiceSale && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 animate-fade-in">
          <div className="bg-white border border-slate-200 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-sky-100 text-sky-700 rounded-xl">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm">ইনভয়েস স্ক্যান করা হয়েছে</h3>
                  <p className="text-[11px] font-mono text-slate-500">#{scannedInvoiceSale.invoice_no}</p>
                </div>
              </div>
              <button
                onClick={() => setShowInvoiceActionModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-1.5 text-xs font-mono">
              <div className="flex justify-between text-slate-600">
                <span>তারিখ ও সময়:</span>
                <span>{new Date(scannedInvoiceSale.created_at).toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>গ্রাহক:</span>
                <span className="font-sans font-bold text-slate-800">{scannedInvoiceSale.customer_name || 'খুচরা ক্রেতা'}</span>
              </div>
              <div className="flex justify-between font-bold text-slate-900 border-t border-slate-200 pt-1.5 text-sm">
                <span>মোট বিল:</span>
                <span className="text-sky-700">৳ {((scannedInvoiceSale.total_paisa || 0) / 100).toFixed(2)}</span>
              </div>
            </div>

            <div className="space-y-2 pt-1">
              <button
                onClick={() => {
                  setShowInvoiceActionModal(false);
                  setShowReturnModal(true);
                }}
                className="w-full py-3 bg-amber-500 hover:bg-amber-600 text-white rounded-2xl font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-amber-500/20 transition-all active:scale-[0.98]"
              >
                <RotateCcw className="w-4 h-4" />
                <span>🔄 রিটার্ন / পণ্য ফেরত ও রিফান্ড প্রসেস করুন</span>
              </button>

              <button
                onClick={() => {
                  setShowInvoiceActionModal(false);
                  setLastInvoiceNo(scannedInvoiceSale.invoice_no);
                  setInvoicePdfBase64('');
                  setShowInvoiceModal(true);
                }}
                className="w-full py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-2xl font-bold text-xs flex items-center justify-center gap-2 border border-slate-300 transition-all active:scale-[0.98]"
              >
                <Printer className="w-4 h-4 text-sky-600" />
                <span>📄 রিসিট / চালান দেখুন ও রিপ্রিন্ট করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Return & Refund Modal */}
      {showReturnModal && scannedInvoiceSale && (
        <ReturnRefundModal
          isOpen={showReturnModal}
          onClose={() => setShowReturnModal(false)}
          sale={scannedInvoiceSale}
          onSuccess={() => {
            setShowReturnModal(false);
            onRefreshProducts();
            toast.success('পণ্য ফেরত ও রিফান্ড সফলভাবে সম্পন্ন হয়েছে!');
          }}
        />
      )}
    </div>
  );
};
