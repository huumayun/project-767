import React, { useState, useEffect } from 'react';
import { SaleRecord, UserSession } from '../../types/ipc';
import {
  ShoppingBag,
  Search,
  Printer,
  RotateCcw,
  Eye,
  CheckCircle2,
  Calendar,
  DollarSign,
  AlertCircle,
  RefreshCw,
} from 'lucide-react';
import { InvoiceModal } from './InvoiceModal';
import { ReturnRefundModal } from './ReturnRefundModal';
import { useToast } from '../../context/ToastContext';

interface SalesHistoryViewProps {
  currentSession: UserSession | null;
}

export const SalesHistoryView: React.FC<SalesHistoryViewProps> = ({ currentSession }) => {
  const toast = useToast();
  const [sales, setSales] = useState<SaleRecord[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Modals
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);
  const [selectedInvoiceNo, setSelectedInvoiceNo] = useState('');
  const [returnTargetSale, setReturnTargetSale] = useState<SaleRecord | null>(null);
  const [showReturnModal, setShowReturnModal] = useState(false);

  const fetchSales = async () => {
    if (!window.api) return;
    setLoading(true);
    setError(null);
    try {
      const data = await window.api.sales.list(100);
      setSales(data);
    } catch (err: any) {
      setError(err.message || 'Failed to load sales.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSales();
  }, []);

  const handleOpenInvoice = (sale: SaleRecord) => {
    setSelectedInvoiceNo(sale.invoice_no);
    setShowInvoiceModal(true);
  };

  const handleOpenReturn = async (sale: SaleRecord) => {
    if (!window.api) return;
    try {
      const fullSale = await window.api.sales.getByInvoice(sale.invoice_no);
      if (fullSale) {
        setReturnTargetSale(fullSale);
        setShowReturnModal(true);
      }
    } catch (err: any) {
      toast.error(`Failed to load sale details: ${err.message}`);
    }
  };

  const filteredSales = sales.filter((s) => {
    if (!search.trim()) return true;
    const q = search.trim().toLowerCase();
    return (
      s.invoice_no.toLowerCase().includes(q) ||
      (s.customer_name && s.customer_name.toLowerCase().includes(q)) ||
      (s.cashier_name && s.cashier_name.toLowerCase().includes(q))
    );
  });

  return (
    <div className="space-y-6 text-slate-900">
      {/* Top Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 bg-white border border-slate-200 p-4 rounded-2xl shadow-sm">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-sky-50 text-sky-600 rounded-xl border border-sky-200">
            <ShoppingBag className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">Sales Transactions & Invoice Archive</h2>
            <p className="text-xs text-slate-500">Search invoices, process customer returns, and reprint receipts</p>
          </div>
        </div>

        <button
          onClick={fetchSales}
          className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl border border-slate-300 transition-colors"
          title="Reload Sales"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Search Toolbar */}
      <div className="bg-white border border-slate-200 p-3 rounded-xl flex items-center gap-3 text-xs shadow-sm">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by Invoice No (e.g. INV-REG01-...), Customer Name, or Cashier..."
            className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-9 pr-3 py-2 text-slate-900 text-xs font-sans focus:outline-none focus:border-sky-500 focus:bg-white"
          />
        </div>
      </div>

      {/* Sales Table */}
      <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-100 text-slate-600 uppercase font-mono text-[10px] tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3.5">Invoice No</th>
                <th className="p-3.5">Date & Time</th>
                <th className="p-3.5">Customer</th>
                <th className="p-3.5">Cashier</th>
                <th className="p-3.5 text-right">Total (৳)</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-mono text-[11.5px]">
              {filteredSales.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-12 text-center text-slate-500 font-sans">
                    {loading ? 'Loading sales history...' : 'No sales records found.'}
                  </td>
                </tr>
              ) : (
                filteredSales.map((sale) => (
                  <tr key={sale.id} className="hover:bg-slate-50 transition-colors">
                    <td className="p-3.5 font-bold text-sky-700">{sale.invoice_no}</td>
                    <td className="p-3.5 text-slate-600">
                      {new Date(sale.created_at).toLocaleDateString()} {new Date(sale.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </td>
                    <td className="p-3.5 font-sans text-slate-800">
                      {sale.customer_name || <span className="text-slate-400 italic">Walk-in Customer</span>}
                    </td>
                    <td className="p-3.5 font-sans text-slate-700">{sale.cashier_name || 'Staff'}</td>
                    <td className="p-3.5 text-right font-bold text-slate-900">
                      ৳ {(sale.total_paisa / 100).toFixed(2)}
                    </td>
                    <td className="p-3.5 text-center">
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          sale.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : sale.status === 'refunded'
                            ? 'bg-rose-100 text-rose-800 border border-rose-300'
                            : 'bg-amber-100 text-amber-800 border border-amber-300'
                        }`}
                      >
                        {sale.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      <div className="flex items-center justify-center gap-1.5 font-sans">
                        <button
                          onClick={() => handleOpenInvoice(sale)}
                          className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-300 transition-colors text-[11px] font-semibold flex items-center gap-1"
                          title="View / Reprint Invoice"
                        >
                          <Printer className="w-3.5 h-3.5 text-sky-600" />
                          <span>Reprint</span>
                        </button>

                        {sale.status === 'completed' && (
                          <button
                            onClick={() => handleOpenReturn(sale)}
                            className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg border border-rose-300 transition-colors text-[11px] font-semibold flex items-center gap-1"
                            title="Process Return / Refund"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>Return</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice Reprint Modal */}
      {selectedInvoiceNo && (
        <InvoiceModal
          isOpen={showInvoiceModal}
          onClose={() => {
            setShowInvoiceModal(false);
            setSelectedInvoiceNo('');
          }}
          invoiceNo={selectedInvoiceNo}
        />
      )}

      {/* Return / Refund Modal */}
      {returnTargetSale && (
        <ReturnRefundModal
          isOpen={showReturnModal}
          onClose={() => {
            setShowReturnModal(false);
            setReturnTargetSale(null);
          }}
          sale={returnTargetSale}
          onSuccess={() => {
            fetchSales();
            setShowReturnModal(false);
          }}
        />
      )}
    </div>
  );
};
