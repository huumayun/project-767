import React, { useState } from 'react';
import { SaleRecord } from '../../types/ipc';
import { RotateCcw, AlertTriangle, CheckCircle2, X } from 'lucide-react';
import { useToast } from '../../context/ToastContext';

interface ReturnRefundModalProps {
  isOpen: boolean;
  onClose: () => void;
  sale: SaleRecord;
  onSuccess: () => void;
}

export const ReturnRefundModal: React.FC<ReturnRefundModalProps> = ({
  isOpen,
  onClose,
  sale,
  onSuccess,
}) => {
  const toast = useToast();
  const [reason, setReason] = useState('Customer returned item');
  const [refundMethod, setRefundMethod] = useState<'cash' | 'bkash' | 'nagad' | 'card'>('cash');
  const [returnQtys, setReturnQtys] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const items = sale.items || [];

  const handleQtyChange = (itemId: string, maxQty: number, val: number) => {
    const safeVal = Math.max(0, Math.min(maxQty, val));
    setReturnQtys((prev) => ({ ...prev, [itemId]: safeVal }));
  };

  const returnPayloadItems = items
    .filter((it) => (returnQtys[it.id] || 0) > 0)
    .map((it) => {
      const q = returnQtys[it.id];
      const itemUnitPrice = it.unit_price_paisa;
      return {
        sale_item_id: it.id,
        product_id: it.product_id,
        qty: q,
        amount_paisa: q * itemUnitPrice,
      };
    });

  const totalRefundPaisa = returnPayloadItems.reduce((s, i) => s + i.amount_paisa, 0);

  const handleSubmitReturn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (returnPayloadItems.length === 0) {
      toast.warning('Please specify quantity to return for at least one item.');
      return;
    }
    if (!window.api) return;

    setLoading(true);
    setError(null);
    try {
      const res = await window.api.sales.processReturn({
        sale_id: sale.id,
        reason,
        refund_method: refundMethod,
        items: returnPayloadItems,
      });
      if (res.success) {
        toast.success('Return processed successfully! Stock restored and refund recorded.');
        onSuccess();
      }
    } catch (err: any) {
      toast.error(err.message || 'Failed to process return.');
      setError(err.message || 'Failed to process return.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4 overflow-y-auto font-sans animate-in fade-in">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-6 shadow-2xl text-slate-900 my-8 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-rose-50 text-rose-600 rounded-xl border border-rose-200 shadow-sm">
              <RotateCcw className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Process Sale Return & Refund</h3>
              <p className="text-xs text-slate-500 font-mono">Invoice: {sale.invoice_no}</p>
            </div>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-slate-700 font-bold">
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmitReturn} className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 block">Select Items & Quantities to Return:</label>
            <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl bg-slate-50 p-2 max-h-48 overflow-y-auto">
              {items.map((it) => (
                <div key={it.id} className="py-2 flex items-center justify-between gap-3 text-xs">
                  <div className="min-w-0 flex-1">
                    <div className="font-bold text-slate-900 truncate">{it.product_name}</div>
                    <div className="text-[11px] text-slate-500 font-mono">
                      Sold: {it.qty} · Unit: ৳{(it.unit_price_paisa / 100).toFixed(2)}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-500">Return Qty:</span>
                    <input
                      type="number"
                      min="0"
                      max={it.qty}
                      value={returnQtys[it.id] || 0}
                      onChange={(e) => handleQtyChange(it.id, it.qty, parseInt(e.target.value, 10) || 0)}
                      className="w-16 bg-white border border-slate-300 rounded px-2 py-1 text-center font-bold text-xs focus:outline-none focus:border-sky-500 font-mono"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Return Reason</label>
              <input
                type="text"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                required
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">Refund Payout Method</label>
              <select
                value={refundMethod}
                onChange={(e) => setRefundMethod(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-sky-500 font-semibold"
              >
                <option value="cash">Cash Out</option>
                <option value="bkash">bKash Refund</option>
                <option value="nagad">Nagad Refund</option>
                <option value="card">Card Reversal</option>
              </select>
            </div>
          </div>

          <div className="bg-rose-50 border border-rose-200 rounded-xl p-3.5 flex items-center justify-between text-xs font-mono">
            <span className="text-rose-800 font-sans font-bold">Total Refund Payout:</span>
            <span className="text-base font-extrabold text-rose-700">
              ৳ {(totalRefundPaisa / 100).toFixed(2)}
            </span>
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading || totalRefundPaisa === 0}
              className="px-5 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl text-xs shadow-md shadow-rose-600/20 disabled:opacity-50 transition-all"
            >
              {loading ? 'Processing...' : 'Confirm Refund & Restock'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
