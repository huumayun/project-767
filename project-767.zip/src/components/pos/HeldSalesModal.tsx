import React, { useState, useEffect } from 'react';
import { HeldSale, CartItem } from '../../types/ipc';
import { Layers, RotateCcw, Trash2, X, Clock, ShoppingCart } from 'lucide-react';
import { ConfirmModal } from '../common/ConfirmModal';
import { useToast } from '../../context/ToastContext';

interface HeldSalesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRestoreCart: (cart: CartItem[]) => void;
}

export const HeldSalesModal: React.FC<HeldSalesModalProps> = ({
  isOpen,
  onClose,
  onRestoreCart,
}) => {
  const toast = useToast();
  const [heldSales, setHeldSales] = useState<HeldSale[]>([]);
  const [loading, setLoading] = useState(false);
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  const fetchHeld = async () => {
    if (!window.api) return;
    setLoading(true);
    try {
      const list = await window.api.sales.getHeldSales();
      setHeldSales(list);
    } catch (err) {
      console.error('Failed to load held sales:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) fetchHeld();
  }, [isOpen]);

  if (!isOpen) return null;

  const confirmDelete = async () => {
    if (!deleteTargetId || !window.api) return;
    try {
      await window.api.sales.deleteHeldSale(deleteTargetId);
      toast.success('Parked cart discarded successfully.');
      setDeleteTargetId(null);
      fetchHeld();
    } catch (err: any) {
      toast.error(`Failed to delete held sale: ${err.message}`);
    }
  };

  const handleRestore = (sale: HeldSale) => {
    if (sale.detail && sale.detail.cartData) {
      onRestoreCart(sale.detail.cartData);
      toast.info(`Cart restored with ${sale.detail.cartData.length} items.`);
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4 animate-in fade-in">
        <div className="bg-white border border-slate-200 rounded-2xl max-w-xl w-full p-6 shadow-2xl text-slate-900 space-y-4 font-sans">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-amber-50 text-amber-600 rounded-xl border border-amber-200 shadow-sm">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">Parked / Held Sales</h3>
                <p className="text-xs text-slate-500 font-mono">Resume customer checkout carts</p>
              </div>
            </div>

            <button onClick={onClose} className="text-slate-400 hover:text-slate-700 font-bold">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 border border-slate-200 rounded-xl bg-slate-50">
            {heldSales.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs font-sans">
                No parked sales found.
              </div>
            ) : (
              heldSales.map((sale) => {
                const cartItems: CartItem[] = sale.detail?.cartData || [];
                const totalPaisa = cartItems.reduce(
                  (sum, i) => sum + i.unit_price_paisa * i.qty,
                  0
                );

                return (
                  <div key={sale.id} className="p-3.5 flex items-center justify-between gap-3 hover:bg-white transition-colors">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs font-mono text-sky-700">{sale.invoice_no}</span>
                        {sale.detail?.customerName && (
                          <span className="text-xs text-slate-700 font-semibold bg-slate-200 px-2 py-0.5 rounded">
                            {sale.detail.customerName}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>{new Date(sale.created_at).toLocaleTimeString()}</span>
                        <span>•</span>
                        <span>{cartItems.length} items</span>
                        <span>•</span>
                        <span className="font-bold text-emerald-700">৳ {(totalPaisa / 100).toFixed(2)}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleRestore(sale)}
                        className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-lg text-xs flex items-center gap-1 shadow-sm transition-colors"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Restore</span>
                      </button>

                      <button
                        onClick={() => setDeleteTargetId(sale.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Discard"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      <ConfirmModal
        isOpen={Boolean(deleteTargetId)}
        title="Discard Held Cart"
        message="Are you sure you want to permanently discard this parked cart?"
        isDanger
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTargetId(null)}
      />
    </>
  );
};
